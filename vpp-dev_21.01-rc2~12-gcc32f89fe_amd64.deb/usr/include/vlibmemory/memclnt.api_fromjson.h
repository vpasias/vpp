/* Imported API files */
#ifndef included_memclnt_api_fromjson_h
#define included_memclnt_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline void *vl_api_module_version_t_fromjson (void *mp, int *len, cJSON *o, vl_api_module_version_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "major");
    if (!item) return 0;
    // start field major
    vl_api_u32_fromjson(item, &a->major);
    // end field major
    item = cJSON_GetObjectItem(o, "minor");
    if (!item) return 0;
    // start field minor
    vl_api_u32_fromjson(item, &a->minor);
    // end field minor
    item = cJSON_GetObjectItem(o, "patch");
    if (!item) return 0;
    // start field patch
    vl_api_u32_fromjson(item, &a->patch);
    // end field patch
    item = cJSON_GetObjectItem(o, "name");
    if (!item) return 0;
    strncpy_s((char *)a->name, sizeof(a->name), cJSON_GetStringValue(item), sizeof(a->name) - 1);
    return mp;
}
static inline void *vl_api_message_table_entry_t_fromjson (void *mp, int *len, cJSON *o, vl_api_message_table_entry_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "index");
    if (!item) return 0;
    // start field index
    vl_api_u16_fromjson(item, &a->index);
    // end field index
    item = cJSON_GetObjectItem(o, "name");
    if (!item) return 0;
    strncpy_s((char *)a->name, sizeof(a->name), cJSON_GetStringValue(item), sizeof(a->name) - 1);
    return mp;
}
/* Manual print memclnt_create */
static inline vl_api_memclnt_create_reply_t *vl_api_memclnt_create_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_memclnt_create_reply_t);
    vl_api_memclnt_create_reply_t *a = malloc(l);
    // processing memclnt_create_reply: i32 response
    item = cJSON_GetObjectItem(o, "response");
    if (!item) return 0;
    // start field response
    vl_api_i32_fromjson(item, &a->response);
    // end field response

    // processing memclnt_create_reply: u64 handle
    item = cJSON_GetObjectItem(o, "handle");
    if (!item) return 0;
    // start field handle
    vl_api_u64_fromjson(item, &a->handle);
    // end field handle

    // processing memclnt_create_reply: u32 index
    item = cJSON_GetObjectItem(o, "index");
    if (!item) return 0;
    // start field index
    vl_api_u32_fromjson(item, &a->index);
    // end field index

    // processing memclnt_create_reply: u64 message_table
    item = cJSON_GetObjectItem(o, "message_table");
    if (!item) return 0;
    // start field message_table
    vl_api_u64_fromjson(item, &a->message_table);
    // end field message_table


    *len = l;
    return a;
}
/* Manual print memclnt_delete */
static inline vl_api_memclnt_delete_reply_t *vl_api_memclnt_delete_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_memclnt_delete_reply_t);
    vl_api_memclnt_delete_reply_t *a = malloc(l);
    // processing memclnt_delete_reply: i32 response
    item = cJSON_GetObjectItem(o, "response");
    if (!item) return 0;
    // start field response
    vl_api_i32_fromjson(item, &a->response);
    // end field response

    // processing memclnt_delete_reply: u64 handle
    item = cJSON_GetObjectItem(o, "handle");
    if (!item) return 0;
    // start field handle
    vl_api_u64_fromjson(item, &a->handle);
    // end field handle


    *len = l;
    return a;
}
static inline vl_api_rx_thread_exit_t *vl_api_rx_thread_exit_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_rx_thread_exit_t);
    vl_api_rx_thread_exit_t *a = malloc(l);
    // processing rx_thread_exit: u8 dummy
    item = cJSON_GetObjectItem(o, "dummy");
    if (!item) return 0;
    // start field dummy
    vl_api_u8_fromjson(item, &a->dummy);
    // end field dummy


    *len = l;
    return a;
}
static inline vl_api_memclnt_rx_thread_suspend_t *vl_api_memclnt_rx_thread_suspend_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_memclnt_rx_thread_suspend_t);
    vl_api_memclnt_rx_thread_suspend_t *a = malloc(l);
    // processing memclnt_rx_thread_suspend: u8 dummy
    item = cJSON_GetObjectItem(o, "dummy");
    if (!item) return 0;
    // start field dummy
    vl_api_u8_fromjson(item, &a->dummy);
    // end field dummy


    *len = l;
    return a;
}
static inline vl_api_memclnt_read_timeout_t *vl_api_memclnt_read_timeout_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_memclnt_read_timeout_t);
    vl_api_memclnt_read_timeout_t *a = malloc(l);
    // processing memclnt_read_timeout: u8 dummy
    item = cJSON_GetObjectItem(o, "dummy");
    if (!item) return 0;
    // start field dummy
    vl_api_u8_fromjson(item, &a->dummy);
    // end field dummy


    *len = l;
    return a;
}
static inline vl_api_rpc_call_t *vl_api_rpc_call_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_rpc_call_t);
    vl_api_rpc_call_t *a = malloc(l);
    // processing rpc_call: u64 function
    item = cJSON_GetObjectItem(o, "function");
    if (!item) return 0;
    // start field function
    vl_api_u64_fromjson(item, &a->function);
    // end field function

    // processing rpc_call: u8 multicast
    item = cJSON_GetObjectItem(o, "multicast");
    if (!item) return 0;
    // start field multicast
    vl_api_u8_fromjson(item, &a->multicast);
    // end field multicast

    // processing rpc_call: u8 need_barrier_sync
    item = cJSON_GetObjectItem(o, "need_barrier_sync");
    if (!item) return 0;
    // start field need_barrier_sync
    vl_api_u8_fromjson(item, &a->need_barrier_sync);
    // end field need_barrier_sync

    // processing rpc_call: u8 send_reply
    item = cJSON_GetObjectItem(o, "send_reply");
    if (!item) return 0;
    // start field send_reply
    vl_api_u8_fromjson(item, &a->send_reply);
    // end field send_reply

    // processing rpc_call: u8 data
    item = cJSON_GetObjectItem(o, "data");
    if (!item) return 0;
    s = u8string_fromjson(o, "data");
    if (!s) return 0;
    a->data_len = vec_len(s);
    a = realloc(a, l + vec_len(s));
    memcpy((void *)a + l, s, vec_len(s));
    l += vec_len(s);
    vec_free(s);


    *len = l;
    return a;
}
static inline vl_api_rpc_call_reply_t *vl_api_rpc_call_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_rpc_call_reply_t);
    vl_api_rpc_call_reply_t *a = malloc(l);
    // processing rpc_call_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_get_first_msg_id_t *vl_api_get_first_msg_id_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_get_first_msg_id_t);
    vl_api_get_first_msg_id_t *a = malloc(l);
    // processing get_first_msg_id: string name
    item = cJSON_GetObjectItem(o, "name");
    if (!item) return 0;
    strncpy_s((char *)a->name, sizeof(a->name), cJSON_GetStringValue(item), sizeof(a->name) - 1);


    *len = l;
    return a;
}
static inline vl_api_get_first_msg_id_reply_t *vl_api_get_first_msg_id_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_get_first_msg_id_reply_t);
    vl_api_get_first_msg_id_reply_t *a = malloc(l);
    // processing get_first_msg_id_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing get_first_msg_id_reply: u16 first_msg_id
    item = cJSON_GetObjectItem(o, "first_msg_id");
    if (!item) return 0;
    // start field first_msg_id
    vl_api_u16_fromjson(item, &a->first_msg_id);
    // end field first_msg_id


    *len = l;
    return a;
}
static inline vl_api_api_versions_t *vl_api_api_versions_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_api_versions_t);
    vl_api_api_versions_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_api_versions_reply_t *vl_api_api_versions_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_api_versions_reply_t);
    vl_api_api_versions_reply_t *a = malloc(l);
    // processing api_versions_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing api_versions_reply: vl_api_module_version_t api_versions
    item = cJSON_GetObjectItem(o, "api_versions");
    if (!item) return 0;
    {
        int i;
        cJSON *array = cJSON_GetObjectItem(o, "api_versions");
        int size = cJSON_GetArraySize(array);
        a->count = size;
        a = realloc(a, l + sizeof(vl_api_module_version_t) * size);
        vl_api_module_version_t *d = (void *)a + l;
        l += sizeof(vl_api_module_version_t) * size;
        for (i = 0; i < size; i++) {
            cJSON *e = cJSON_GetArrayItem(array, i);
            vl_api_module_version_t_fromjson(a, len, e, &d[i]); 
        }
    }


    *len = l;
    return a;
}
/* Manual print trace_plugin_msg_ids */
static inline vl_api_sockclnt_create_t *vl_api_sockclnt_create_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sockclnt_create_t);
    vl_api_sockclnt_create_t *a = malloc(l);
    // processing sockclnt_create: string name
    item = cJSON_GetObjectItem(o, "name");
    if (!item) return 0;
    strncpy_s((char *)a->name, sizeof(a->name), cJSON_GetStringValue(item), sizeof(a->name) - 1);


    *len = l;
    return a;
}
static inline vl_api_sockclnt_create_reply_t *vl_api_sockclnt_create_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sockclnt_create_reply_t);
    vl_api_sockclnt_create_reply_t *a = malloc(l);
    // processing sockclnt_create_reply: i32 response
    item = cJSON_GetObjectItem(o, "response");
    if (!item) return 0;
    // start field response
    vl_api_i32_fromjson(item, &a->response);
    // end field response

    // processing sockclnt_create_reply: u32 index
    item = cJSON_GetObjectItem(o, "index");
    if (!item) return 0;
    // start field index
    vl_api_u32_fromjson(item, &a->index);
    // end field index

    // processing sockclnt_create_reply: vl_api_message_table_entry_t message_table
    item = cJSON_GetObjectItem(o, "message_table");
    if (!item) return 0;
    {
        int i;
        cJSON *array = cJSON_GetObjectItem(o, "message_table");
        int size = cJSON_GetArraySize(array);
        a->count = size;
        a = realloc(a, l + sizeof(vl_api_message_table_entry_t) * size);
        vl_api_message_table_entry_t *d = (void *)a + l;
        l += sizeof(vl_api_message_table_entry_t) * size;
        for (i = 0; i < size; i++) {
            cJSON *e = cJSON_GetArrayItem(array, i);
            vl_api_message_table_entry_t_fromjson(a, len, e, &d[i]); 
        }
    }


    *len = l;
    return a;
}
static inline vl_api_sockclnt_delete_t *vl_api_sockclnt_delete_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sockclnt_delete_t);
    vl_api_sockclnt_delete_t *a = malloc(l);
    // processing sockclnt_delete: u32 index
    item = cJSON_GetObjectItem(o, "index");
    if (!item) return 0;
    // start field index
    vl_api_u32_fromjson(item, &a->index);
    // end field index


    *len = l;
    return a;
}
static inline vl_api_sockclnt_delete_reply_t *vl_api_sockclnt_delete_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sockclnt_delete_reply_t);
    vl_api_sockclnt_delete_reply_t *a = malloc(l);
    // processing sockclnt_delete_reply: i32 response
    item = cJSON_GetObjectItem(o, "response");
    if (!item) return 0;
    // start field response
    vl_api_i32_fromjson(item, &a->response);
    // end field response


    *len = l;
    return a;
}
static inline vl_api_sock_init_shm_t *vl_api_sock_init_shm_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sock_init_shm_t);
    vl_api_sock_init_shm_t *a = malloc(l);
    // processing sock_init_shm: u32 requested_size
    item = cJSON_GetObjectItem(o, "requested_size");
    if (!item) return 0;
    // start field requested_size
    vl_api_u32_fromjson(item, &a->requested_size);
    // end field requested_size

    // processing sock_init_shm: u64 configs
    item = cJSON_GetObjectItem(o, "configs");
    if (!item) return 0;
    {
        int i;
        cJSON *array = cJSON_GetObjectItem(o, "configs");
        int size = cJSON_GetArraySize(array);
        a->nitems = size;
        a = realloc(a, l + sizeof(u64) * size);
        u64 *d = (void *)a + l;
        l += sizeof(u64) * size;
        for (i = 0; i < size; i++) {
            cJSON *e = cJSON_GetArrayItem(array, i);
            vl_api_u64_fromjson(e, &d[i]);
        }
    }


    *len = l;
    return a;
}
static inline vl_api_sock_init_shm_reply_t *vl_api_sock_init_shm_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sock_init_shm_reply_t);
    vl_api_sock_init_shm_reply_t *a = malloc(l);
    // processing sock_init_shm_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_memclnt_keepalive_t *vl_api_memclnt_keepalive_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_memclnt_keepalive_t);
    vl_api_memclnt_keepalive_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_memclnt_keepalive_reply_t *vl_api_memclnt_keepalive_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_memclnt_keepalive_reply_t);
    vl_api_memclnt_keepalive_reply_t *a = malloc(l);
    // processing memclnt_keepalive_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
#endif
