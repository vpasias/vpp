/* Imported API files */
#ifndef included_memclnt_api_tojson_h
#define included_memclnt_api_tojson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline cJSON *vl_api_module_version_t_tojson (vl_api_module_version_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddNumberToObject(o, "major", a->major);
    cJSON_AddNumberToObject(o, "minor", a->minor);
    cJSON_AddNumberToObject(o, "patch", a->patch);
    cJSON_AddStringToObject(o, "name", (char *)a->name);
    return o;
}
static inline cJSON *vl_api_message_table_entry_t_tojson (vl_api_message_table_entry_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddNumberToObject(o, "index", a->index);
    cJSON_AddStringToObject(o, "name", (char *)a->name);
    return o;
}
/* Manual print memclnt_create */
static inline cJSON *vl_api_memclnt_create_reply_t_tojson (vl_api_memclnt_create_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "memclnt_create_reply");
    cJSON_AddNumberToObject(o, "response", a->response);
    cJSON_AddNumberToObject(o, "handle", a->handle);
    cJSON_AddNumberToObject(o, "index", a->index);
    cJSON_AddNumberToObject(o, "message_table", a->message_table);
    return o;
}
/* Manual print memclnt_delete */
static inline cJSON *vl_api_memclnt_delete_reply_t_tojson (vl_api_memclnt_delete_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "memclnt_delete_reply");
    cJSON_AddNumberToObject(o, "response", a->response);
    cJSON_AddNumberToObject(o, "handle", a->handle);
    return o;
}
static inline cJSON *vl_api_rx_thread_exit_t_tojson (vl_api_rx_thread_exit_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "rx_thread_exit");
    cJSON_AddNumberToObject(o, "dummy", a->dummy);
    return o;
}
static inline cJSON *vl_api_memclnt_rx_thread_suspend_t_tojson (vl_api_memclnt_rx_thread_suspend_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "memclnt_rx_thread_suspend");
    cJSON_AddNumberToObject(o, "dummy", a->dummy);
    return o;
}
static inline cJSON *vl_api_memclnt_read_timeout_t_tojson (vl_api_memclnt_read_timeout_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "memclnt_read_timeout");
    cJSON_AddNumberToObject(o, "dummy", a->dummy);
    return o;
}
static inline cJSON *vl_api_rpc_call_t_tojson (vl_api_rpc_call_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "rpc_call");
    cJSON_AddNumberToObject(o, "function", a->function);
    cJSON_AddNumberToObject(o, "multicast", a->multicast);
    cJSON_AddNumberToObject(o, "need_barrier_sync", a->need_barrier_sync);
    cJSON_AddNumberToObject(o, "send_reply", a->send_reply);
    cJSON_AddNumberToObject(o, "data_len", a->data_len);
    {
    u8 *s = format(0, "0x%U", format_hex_bytes, &a->data, a->data_len);
    cJSON_AddStringToObject(o, "data", (char *)s);
    vec_free(s);
    }
    return o;
}
static inline cJSON *vl_api_rpc_call_reply_t_tojson (vl_api_rpc_call_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "rpc_call_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
static inline cJSON *vl_api_get_first_msg_id_t_tojson (vl_api_get_first_msg_id_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "get_first_msg_id");
    cJSON_AddStringToObject(o, "name", (char *)a->name);
    return o;
}
static inline cJSON *vl_api_get_first_msg_id_reply_t_tojson (vl_api_get_first_msg_id_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "get_first_msg_id_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    cJSON_AddNumberToObject(o, "first_msg_id", a->first_msg_id);
    return o;
}
static inline cJSON *vl_api_api_versions_t_tojson (vl_api_api_versions_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "api_versions");
    return o;
}
static inline cJSON *vl_api_api_versions_reply_t_tojson (vl_api_api_versions_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "api_versions_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    cJSON_AddNumberToObject(o, "count", a->count);
    {
        int i;
        cJSON *array = cJSON_AddArrayToObject(o, "api_versions");
        for (i = 0; i < a->count; i++) {
            cJSON_AddItemToArray(array, vl_api_module_version_t_tojson(&a->api_versions[i]));
        }
    }
    return o;
}
/* Manual print trace_plugin_msg_ids */
static inline cJSON *vl_api_sockclnt_create_t_tojson (vl_api_sockclnt_create_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "sockclnt_create");
    cJSON_AddStringToObject(o, "name", (char *)a->name);
    return o;
}
static inline cJSON *vl_api_sockclnt_create_reply_t_tojson (vl_api_sockclnt_create_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "sockclnt_create_reply");
    cJSON_AddNumberToObject(o, "response", a->response);
    cJSON_AddNumberToObject(o, "index", a->index);
    cJSON_AddNumberToObject(o, "count", a->count);
    {
        int i;
        cJSON *array = cJSON_AddArrayToObject(o, "message_table");
        for (i = 0; i < a->count; i++) {
            cJSON_AddItemToArray(array, vl_api_message_table_entry_t_tojson(&a->message_table[i]));
        }
    }
    return o;
}
static inline cJSON *vl_api_sockclnt_delete_t_tojson (vl_api_sockclnt_delete_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "sockclnt_delete");
    cJSON_AddNumberToObject(o, "index", a->index);
    return o;
}
static inline cJSON *vl_api_sockclnt_delete_reply_t_tojson (vl_api_sockclnt_delete_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "sockclnt_delete_reply");
    cJSON_AddNumberToObject(o, "response", a->response);
    return o;
}
static inline cJSON *vl_api_sock_init_shm_t_tojson (vl_api_sock_init_shm_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "sock_init_shm");
    cJSON_AddNumberToObject(o, "requested_size", a->requested_size);
    cJSON_AddNumberToObject(o, "nitems", a->nitems);
    {
        int i;
        cJSON *array = cJSON_AddArrayToObject(o, "configs");
        for (i = 0; i < a->nitems; i++) {
            cJSON_AddItemToArray(array, cJSON_CreateNumber(a->configs[i]));
        }
    }
    return o;
}
static inline cJSON *vl_api_sock_init_shm_reply_t_tojson (vl_api_sock_init_shm_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "sock_init_shm_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
static inline cJSON *vl_api_memclnt_keepalive_t_tojson (vl_api_memclnt_keepalive_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "memclnt_keepalive");
    return o;
}
static inline cJSON *vl_api_memclnt_keepalive_reply_t_tojson (vl_api_memclnt_keepalive_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "memclnt_keepalive_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
#endif
