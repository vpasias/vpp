#ifndef included_cop_api_enum_h
#define included_cop_api_enum_h
typedef enum {
   VL_API_COP_INTERFACE_ENABLE_DISABLE,
   VL_API_COP_INTERFACE_ENABLE_DISABLE_REPLY,
   VL_API_COP_WHITELIST_ENABLE_DISABLE,
   VL_API_COP_WHITELIST_ENABLE_DISABLE_REPLY,
   VL_MSG_COP_LAST
} vl_api_cop_enum_t;
#endif
