/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#ifndef included_cop_api_fromjson_h
#define included_cop_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline vl_api_cop_interface_enable_disable_t *vl_api_cop_interface_enable_disable_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_cop_interface_enable_disable_t);
    vl_api_cop_interface_enable_disable_t *a = malloc(l);
    // processing cop_interface_enable_disable: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing cop_interface_enable_disable: bool enable_disable
    item = cJSON_GetObjectItem(o, "enable_disable");
    if (!item) return 0;
    // start field enable_disable
    vl_api_bool_fromjson(item, &a->enable_disable);
    // end field enable_disable


    *len = l;
    return a;
}
static inline vl_api_cop_interface_enable_disable_reply_t *vl_api_cop_interface_enable_disable_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_cop_interface_enable_disable_reply_t);
    vl_api_cop_interface_enable_disable_reply_t *a = malloc(l);
    // processing cop_interface_enable_disable_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_cop_whitelist_enable_disable_t *vl_api_cop_whitelist_enable_disable_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_cop_whitelist_enable_disable_t);
    vl_api_cop_whitelist_enable_disable_t *a = malloc(l);
    // processing cop_whitelist_enable_disable: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing cop_whitelist_enable_disable: u32 fib_id
    item = cJSON_GetObjectItem(o, "fib_id");
    if (!item) return 0;
    // start field fib_id
    vl_api_u32_fromjson(item, &a->fib_id);
    // end field fib_id

    // processing cop_whitelist_enable_disable: bool ip4
    item = cJSON_GetObjectItem(o, "ip4");
    if (!item) return 0;
    // start field ip4
    vl_api_bool_fromjson(item, &a->ip4);
    // end field ip4

    // processing cop_whitelist_enable_disable: bool ip6
    item = cJSON_GetObjectItem(o, "ip6");
    if (!item) return 0;
    // start field ip6
    vl_api_bool_fromjson(item, &a->ip6);
    // end field ip6

    // processing cop_whitelist_enable_disable: bool default_cop
    item = cJSON_GetObjectItem(o, "default_cop");
    if (!item) return 0;
    // start field default_cop
    vl_api_bool_fromjson(item, &a->default_cop);
    // end field default_cop


    *len = l;
    return a;
}
static inline vl_api_cop_whitelist_enable_disable_reply_t *vl_api_cop_whitelist_enable_disable_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_cop_whitelist_enable_disable_reply_t);
    vl_api_cop_whitelist_enable_disable_reply_t *a = malloc(l);
    // processing cop_whitelist_enable_disable_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
#endif
