/* Imported API files */
#include <vnet/interface_types.api_tojson.h>
#ifndef included_cop_api_tojson_h
#define included_cop_api_tojson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline cJSON *vl_api_cop_interface_enable_disable_t_tojson (vl_api_cop_interface_enable_disable_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "cop_interface_enable_disable");
    cJSON_AddNumberToObject(o, "sw_if_index", a->sw_if_index);
    cJSON_AddBoolToObject(o, "enable_disable", a->enable_disable);
    return o;
}
static inline cJSON *vl_api_cop_interface_enable_disable_reply_t_tojson (vl_api_cop_interface_enable_disable_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "cop_interface_enable_disable_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
static inline cJSON *vl_api_cop_whitelist_enable_disable_t_tojson (vl_api_cop_whitelist_enable_disable_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "cop_whitelist_enable_disable");
    cJSON_AddNumberToObject(o, "sw_if_index", a->sw_if_index);
    cJSON_AddNumberToObject(o, "fib_id", a->fib_id);
    cJSON_AddBoolToObject(o, "ip4", a->ip4);
    cJSON_AddBoolToObject(o, "ip6", a->ip6);
    cJSON_AddBoolToObject(o, "default_cop", a->default_cop);
    return o;
}
static inline cJSON *vl_api_cop_whitelist_enable_disable_reply_t_tojson (vl_api_cop_whitelist_enable_disable_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "cop_whitelist_enable_disable_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
#endif
