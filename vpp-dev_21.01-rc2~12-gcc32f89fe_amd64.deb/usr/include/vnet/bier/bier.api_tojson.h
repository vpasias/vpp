/* Imported API files */
#include <vnet/fib/fib_types.api_tojson.h>
#ifndef included_bier_api_tojson_h
#define included_bier_api_tojson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline cJSON *vl_api_bier_table_id_t_tojson (vl_api_bier_table_id_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddNumberToObject(o, "bt_set", a->bt_set);
    cJSON_AddNumberToObject(o, "bt_sub_domain", a->bt_sub_domain);
    cJSON_AddNumberToObject(o, "bt_hdr_len_id", a->bt_hdr_len_id);
    return o;
}
static inline cJSON *vl_api_bier_route_t_tojson (vl_api_bier_route_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddNumberToObject(o, "br_bp", a->br_bp);
    cJSON_AddItemToObject(o, "br_tbl_id", vl_api_bier_table_id_t_tojson(&a->br_tbl_id));
    cJSON_AddNumberToObject(o, "br_n_paths", a->br_n_paths);
    {
        int i;
        cJSON *array = cJSON_AddArrayToObject(o, "br_paths");
        for (i = 0; i < a->br_n_paths; i++) {
            cJSON_AddItemToArray(array, vl_api_fib_path_t_tojson(&a->br_paths[i]));
        }
    }
    return o;
}
static inline cJSON *vl_api_bier_table_add_del_t_tojson (vl_api_bier_table_add_del_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_table_add_del");
    cJSON_AddItemToObject(o, "bt_tbl_id", vl_api_bier_table_id_t_tojson(&a->bt_tbl_id));
    cJSON_AddNumberToObject(o, "bt_label", a->bt_label);
    cJSON_AddBoolToObject(o, "bt_is_add", a->bt_is_add);
    return o;
}
static inline cJSON *vl_api_bier_table_add_del_reply_t_tojson (vl_api_bier_table_add_del_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_table_add_del_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
static inline cJSON *vl_api_bier_table_dump_t_tojson (vl_api_bier_table_dump_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_table_dump");
    return o;
}
static inline cJSON *vl_api_bier_table_details_t_tojson (vl_api_bier_table_details_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_table_details");
    cJSON_AddNumberToObject(o, "bt_label", a->bt_label);
    cJSON_AddItemToObject(o, "bt_tbl_id", vl_api_bier_table_id_t_tojson(&a->bt_tbl_id));
    return o;
}
static inline cJSON *vl_api_bier_route_add_del_t_tojson (vl_api_bier_route_add_del_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_route_add_del");
    cJSON_AddBoolToObject(o, "br_is_add", a->br_is_add);
    cJSON_AddBoolToObject(o, "br_is_replace", a->br_is_replace);
    cJSON_AddItemToObject(o, "br_route", vl_api_bier_route_t_tojson(&a->br_route));
    return o;
}
static inline cJSON *vl_api_bier_route_add_del_reply_t_tojson (vl_api_bier_route_add_del_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_route_add_del_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
static inline cJSON *vl_api_bier_route_dump_t_tojson (vl_api_bier_route_dump_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_route_dump");
    cJSON_AddItemToObject(o, "br_tbl_id", vl_api_bier_table_id_t_tojson(&a->br_tbl_id));
    return o;
}
static inline cJSON *vl_api_bier_route_details_t_tojson (vl_api_bier_route_details_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_route_details");
    cJSON_AddItemToObject(o, "br_route", vl_api_bier_route_t_tojson(&a->br_route));
    return o;
}
static inline cJSON *vl_api_bier_imp_add_t_tojson (vl_api_bier_imp_add_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_imp_add");
    cJSON_AddItemToObject(o, "bi_tbl_id", vl_api_bier_table_id_t_tojson(&a->bi_tbl_id));
    cJSON_AddNumberToObject(o, "bi_src", a->bi_src);
    cJSON_AddNumberToObject(o, "bi_n_bytes", a->bi_n_bytes);
    {
    u8 *s = format(0, "0x%U", format_hex_bytes, &a->bi_bytes, a->bi_n_bytes);
    cJSON_AddStringToObject(o, "bi_bytes", (char *)s);
    vec_free(s);
    }
    return o;
}
static inline cJSON *vl_api_bier_imp_add_reply_t_tojson (vl_api_bier_imp_add_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_imp_add_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    cJSON_AddNumberToObject(o, "bi_index", a->bi_index);
    return o;
}
static inline cJSON *vl_api_bier_imp_del_t_tojson (vl_api_bier_imp_del_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_imp_del");
    cJSON_AddNumberToObject(o, "bi_index", a->bi_index);
    return o;
}
static inline cJSON *vl_api_bier_imp_del_reply_t_tojson (vl_api_bier_imp_del_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_imp_del_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
static inline cJSON *vl_api_bier_imp_dump_t_tojson (vl_api_bier_imp_dump_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_imp_dump");
    return o;
}
static inline cJSON *vl_api_bier_imp_details_t_tojson (vl_api_bier_imp_details_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_imp_details");
    cJSON_AddItemToObject(o, "bi_tbl_id", vl_api_bier_table_id_t_tojson(&a->bi_tbl_id));
    cJSON_AddNumberToObject(o, "bi_src", a->bi_src);
    cJSON_AddNumberToObject(o, "bi_n_bytes", a->bi_n_bytes);
    {
    u8 *s = format(0, "0x%U", format_hex_bytes, &a->bi_bytes, a->bi_n_bytes);
    cJSON_AddStringToObject(o, "bi_bytes", (char *)s);
    vec_free(s);
    }
    return o;
}
static inline cJSON *vl_api_bier_disp_table_add_del_t_tojson (vl_api_bier_disp_table_add_del_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_disp_table_add_del");
    cJSON_AddNumberToObject(o, "bdt_tbl_id", a->bdt_tbl_id);
    cJSON_AddBoolToObject(o, "bdt_is_add", a->bdt_is_add);
    return o;
}
static inline cJSON *vl_api_bier_disp_table_add_del_reply_t_tojson (vl_api_bier_disp_table_add_del_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_disp_table_add_del_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
static inline cJSON *vl_api_bier_disp_table_dump_t_tojson (vl_api_bier_disp_table_dump_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_disp_table_dump");
    return o;
}
static inline cJSON *vl_api_bier_disp_table_details_t_tojson (vl_api_bier_disp_table_details_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_disp_table_details");
    cJSON_AddNumberToObject(o, "bdt_tbl_id", a->bdt_tbl_id);
    return o;
}
static inline cJSON *vl_api_bier_disp_entry_add_del_t_tojson (vl_api_bier_disp_entry_add_del_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_disp_entry_add_del");
    cJSON_AddNumberToObject(o, "bde_bp", a->bde_bp);
    cJSON_AddNumberToObject(o, "bde_tbl_id", a->bde_tbl_id);
    cJSON_AddBoolToObject(o, "bde_is_add", a->bde_is_add);
    cJSON_AddNumberToObject(o, "bde_payload_proto", a->bde_payload_proto);
    cJSON_AddNumberToObject(o, "bde_n_paths", a->bde_n_paths);
    {
        int i;
        cJSON *array = cJSON_AddArrayToObject(o, "bde_paths");
        for (i = 0; i < a->bde_n_paths; i++) {
            cJSON_AddItemToArray(array, vl_api_fib_path_t_tojson(&a->bde_paths[i]));
        }
    }
    return o;
}
static inline cJSON *vl_api_bier_disp_entry_add_del_reply_t_tojson (vl_api_bier_disp_entry_add_del_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_disp_entry_add_del_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
static inline cJSON *vl_api_bier_disp_entry_dump_t_tojson (vl_api_bier_disp_entry_dump_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_disp_entry_dump");
    cJSON_AddNumberToObject(o, "bde_tbl_id", a->bde_tbl_id);
    return o;
}
static inline cJSON *vl_api_bier_disp_entry_details_t_tojson (vl_api_bier_disp_entry_details_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "bier_disp_entry_details");
    cJSON_AddNumberToObject(o, "bde_bp", a->bde_bp);
    cJSON_AddNumberToObject(o, "bde_tbl_id", a->bde_tbl_id);
    cJSON_AddBoolToObject(o, "bde_is_add", a->bde_is_add);
    cJSON_AddNumberToObject(o, "bde_payload_proto", a->bde_payload_proto);
    cJSON_AddNumberToObject(o, "bde_n_paths", a->bde_n_paths);
    {
        int i;
        cJSON *array = cJSON_AddArrayToObject(o, "bde_paths");
        for (i = 0; i < a->bde_n_paths; i++) {
            cJSON_AddItemToArray(array, vl_api_fib_path_t_tojson(&a->bde_paths[i]));
        }
    }
    return o;
}
#endif
