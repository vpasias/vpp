/* Imported API files */
#include <vnet/fib/fib_types.api_fromjson.h>
#ifndef included_bier_api_fromjson_h
#define included_bier_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline void *vl_api_bier_table_id_t_fromjson (void *mp, int *len, cJSON *o, vl_api_bier_table_id_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "bt_set");
    if (!item) return 0;
    // start field bt_set
    vl_api_u8_fromjson(item, &a->bt_set);
    // end field bt_set
    item = cJSON_GetObjectItem(o, "bt_sub_domain");
    if (!item) return 0;
    // start field bt_sub_domain
    vl_api_u8_fromjson(item, &a->bt_sub_domain);
    // end field bt_sub_domain
    item = cJSON_GetObjectItem(o, "bt_hdr_len_id");
    if (!item) return 0;
    // start field bt_hdr_len_id
    vl_api_u8_fromjson(item, &a->bt_hdr_len_id);
    // end field bt_hdr_len_id
    return mp;
}
static inline void *vl_api_bier_route_t_fromjson (void *mp, int *len, cJSON *o, vl_api_bier_route_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "br_bp");
    if (!item) return 0;
    // start field br_bp
    vl_api_u32_fromjson(item, &a->br_bp);
    // end field br_bp
    item = cJSON_GetObjectItem(o, "br_tbl_id");
    if (!item) return 0;
    // start field br_tbl_id
    mp = vl_api_bier_table_id_t_fromjson(mp, len, item, &a->br_tbl_id);
    if (!mp) return 0;
    // end field br_tbl_id
    item = cJSON_GetObjectItem(o, "br_paths");
    if (!item) return 0;
    {
        int i;
        cJSON *array = cJSON_GetObjectItem(o, "br_paths");
        int size = cJSON_GetArraySize(array);
        a->br_n_paths = size;
        mp = realloc(mp, *len + sizeof(vl_api_fib_path_t) * size);
        vl_api_fib_path_t *d = (void *)mp + *len;
        *len += sizeof(vl_api_fib_path_t) * size;
        for (i = 0; i < size; i++) {
            cJSON *e = cJSON_GetArrayItem(array, i);
            vl_api_fib_path_t_fromjson(mp, len, e, &d[i]); 
        }
    }
    return mp;
}
static inline vl_api_bier_table_add_del_t *vl_api_bier_table_add_del_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_table_add_del_t);
    vl_api_bier_table_add_del_t *a = malloc(l);
    // processing bier_table_add_del: vl_api_bier_table_id_t bt_tbl_id
    item = cJSON_GetObjectItem(o, "bt_tbl_id");
    if (!item) return 0;
    // start field bt_tbl_id
    a = vl_api_bier_table_id_t_fromjson(a, &l, item, &a->bt_tbl_id);
    if (!a) return 0;
    // end field bt_tbl_id

    // processing bier_table_add_del: u32 bt_label
    item = cJSON_GetObjectItem(o, "bt_label");
    if (!item) return 0;
    // start field bt_label
    vl_api_u32_fromjson(item, &a->bt_label);
    // end field bt_label

    // processing bier_table_add_del: bool bt_is_add
    item = cJSON_GetObjectItem(o, "bt_is_add");
    if (!item) return 0;
    // start field bt_is_add
    vl_api_bool_fromjson(item, &a->bt_is_add);
    // end field bt_is_add


    *len = l;
    return a;
}
static inline vl_api_bier_table_add_del_reply_t *vl_api_bier_table_add_del_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_table_add_del_reply_t);
    vl_api_bier_table_add_del_reply_t *a = malloc(l);
    // processing bier_table_add_del_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bier_table_dump_t *vl_api_bier_table_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_table_dump_t);
    vl_api_bier_table_dump_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_bier_table_details_t *vl_api_bier_table_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_table_details_t);
    vl_api_bier_table_details_t *a = malloc(l);
    // processing bier_table_details: u32 bt_label
    item = cJSON_GetObjectItem(o, "bt_label");
    if (!item) return 0;
    // start field bt_label
    vl_api_u32_fromjson(item, &a->bt_label);
    // end field bt_label

    // processing bier_table_details: vl_api_bier_table_id_t bt_tbl_id
    item = cJSON_GetObjectItem(o, "bt_tbl_id");
    if (!item) return 0;
    // start field bt_tbl_id
    a = vl_api_bier_table_id_t_fromjson(a, &l, item, &a->bt_tbl_id);
    if (!a) return 0;
    // end field bt_tbl_id


    *len = l;
    return a;
}
static inline vl_api_bier_route_add_del_t *vl_api_bier_route_add_del_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_route_add_del_t);
    vl_api_bier_route_add_del_t *a = malloc(l);
    // processing bier_route_add_del: bool br_is_add
    item = cJSON_GetObjectItem(o, "br_is_add");
    if (!item) return 0;
    // start field br_is_add
    vl_api_bool_fromjson(item, &a->br_is_add);
    // end field br_is_add

    // processing bier_route_add_del: bool br_is_replace
    item = cJSON_GetObjectItem(o, "br_is_replace");
    if (!item) return 0;
    // start field br_is_replace
    vl_api_bool_fromjson(item, &a->br_is_replace);
    // end field br_is_replace

    // processing bier_route_add_del: vl_api_bier_route_t br_route
    item = cJSON_GetObjectItem(o, "br_route");
    if (!item) return 0;
    // start field br_route
    a = vl_api_bier_route_t_fromjson(a, &l, item, &a->br_route);
    if (!a) return 0;
    // end field br_route


    *len = l;
    return a;
}
static inline vl_api_bier_route_add_del_reply_t *vl_api_bier_route_add_del_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_route_add_del_reply_t);
    vl_api_bier_route_add_del_reply_t *a = malloc(l);
    // processing bier_route_add_del_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bier_route_dump_t *vl_api_bier_route_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_route_dump_t);
    vl_api_bier_route_dump_t *a = malloc(l);
    // processing bier_route_dump: vl_api_bier_table_id_t br_tbl_id
    item = cJSON_GetObjectItem(o, "br_tbl_id");
    if (!item) return 0;
    // start field br_tbl_id
    a = vl_api_bier_table_id_t_fromjson(a, &l, item, &a->br_tbl_id);
    if (!a) return 0;
    // end field br_tbl_id


    *len = l;
    return a;
}
static inline vl_api_bier_route_details_t *vl_api_bier_route_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_route_details_t);
    vl_api_bier_route_details_t *a = malloc(l);
    // processing bier_route_details: vl_api_bier_route_t br_route
    item = cJSON_GetObjectItem(o, "br_route");
    if (!item) return 0;
    // start field br_route
    a = vl_api_bier_route_t_fromjson(a, &l, item, &a->br_route);
    if (!a) return 0;
    // end field br_route


    *len = l;
    return a;
}
static inline vl_api_bier_imp_add_t *vl_api_bier_imp_add_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_imp_add_t);
    vl_api_bier_imp_add_t *a = malloc(l);
    // processing bier_imp_add: vl_api_bier_table_id_t bi_tbl_id
    item = cJSON_GetObjectItem(o, "bi_tbl_id");
    if (!item) return 0;
    // start field bi_tbl_id
    a = vl_api_bier_table_id_t_fromjson(a, &l, item, &a->bi_tbl_id);
    if (!a) return 0;
    // end field bi_tbl_id

    // processing bier_imp_add: u16 bi_src
    item = cJSON_GetObjectItem(o, "bi_src");
    if (!item) return 0;
    // start field bi_src
    vl_api_u16_fromjson(item, &a->bi_src);
    // end field bi_src

    // processing bier_imp_add: u8 bi_bytes
    item = cJSON_GetObjectItem(o, "bi_bytes");
    if (!item) return 0;
    s = u8string_fromjson(o, "bi_bytes");
    if (!s) return 0;
    a->bi_n_bytes = vec_len(s);
    a = realloc(a, l + vec_len(s));
    memcpy((void *)a + l, s, vec_len(s));
    l += vec_len(s);
    vec_free(s);


    *len = l;
    return a;
}
static inline vl_api_bier_imp_add_reply_t *vl_api_bier_imp_add_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_imp_add_reply_t);
    vl_api_bier_imp_add_reply_t *a = malloc(l);
    // processing bier_imp_add_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing bier_imp_add_reply: u32 bi_index
    item = cJSON_GetObjectItem(o, "bi_index");
    if (!item) return 0;
    // start field bi_index
    vl_api_u32_fromjson(item, &a->bi_index);
    // end field bi_index


    *len = l;
    return a;
}
static inline vl_api_bier_imp_del_t *vl_api_bier_imp_del_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_imp_del_t);
    vl_api_bier_imp_del_t *a = malloc(l);
    // processing bier_imp_del: u32 bi_index
    item = cJSON_GetObjectItem(o, "bi_index");
    if (!item) return 0;
    // start field bi_index
    vl_api_u32_fromjson(item, &a->bi_index);
    // end field bi_index


    *len = l;
    return a;
}
static inline vl_api_bier_imp_del_reply_t *vl_api_bier_imp_del_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_imp_del_reply_t);
    vl_api_bier_imp_del_reply_t *a = malloc(l);
    // processing bier_imp_del_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bier_imp_dump_t *vl_api_bier_imp_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_imp_dump_t);
    vl_api_bier_imp_dump_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_bier_imp_details_t *vl_api_bier_imp_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_imp_details_t);
    vl_api_bier_imp_details_t *a = malloc(l);
    // processing bier_imp_details: vl_api_bier_table_id_t bi_tbl_id
    item = cJSON_GetObjectItem(o, "bi_tbl_id");
    if (!item) return 0;
    // start field bi_tbl_id
    a = vl_api_bier_table_id_t_fromjson(a, &l, item, &a->bi_tbl_id);
    if (!a) return 0;
    // end field bi_tbl_id

    // processing bier_imp_details: u16 bi_src
    item = cJSON_GetObjectItem(o, "bi_src");
    if (!item) return 0;
    // start field bi_src
    vl_api_u16_fromjson(item, &a->bi_src);
    // end field bi_src

    // processing bier_imp_details: u8 bi_bytes
    item = cJSON_GetObjectItem(o, "bi_bytes");
    if (!item) return 0;
    s = u8string_fromjson(o, "bi_bytes");
    if (!s) return 0;
    a->bi_n_bytes = vec_len(s);
    a = realloc(a, l + vec_len(s));
    memcpy((void *)a + l, s, vec_len(s));
    l += vec_len(s);
    vec_free(s);


    *len = l;
    return a;
}
static inline vl_api_bier_disp_table_add_del_t *vl_api_bier_disp_table_add_del_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_disp_table_add_del_t);
    vl_api_bier_disp_table_add_del_t *a = malloc(l);
    // processing bier_disp_table_add_del: u32 bdt_tbl_id
    item = cJSON_GetObjectItem(o, "bdt_tbl_id");
    if (!item) return 0;
    // start field bdt_tbl_id
    vl_api_u32_fromjson(item, &a->bdt_tbl_id);
    // end field bdt_tbl_id

    // processing bier_disp_table_add_del: bool bdt_is_add
    item = cJSON_GetObjectItem(o, "bdt_is_add");
    if (!item) return 0;
    // start field bdt_is_add
    vl_api_bool_fromjson(item, &a->bdt_is_add);
    // end field bdt_is_add


    *len = l;
    return a;
}
static inline vl_api_bier_disp_table_add_del_reply_t *vl_api_bier_disp_table_add_del_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_disp_table_add_del_reply_t);
    vl_api_bier_disp_table_add_del_reply_t *a = malloc(l);
    // processing bier_disp_table_add_del_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bier_disp_table_dump_t *vl_api_bier_disp_table_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_disp_table_dump_t);
    vl_api_bier_disp_table_dump_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_bier_disp_table_details_t *vl_api_bier_disp_table_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_disp_table_details_t);
    vl_api_bier_disp_table_details_t *a = malloc(l);
    // processing bier_disp_table_details: u32 bdt_tbl_id
    item = cJSON_GetObjectItem(o, "bdt_tbl_id");
    if (!item) return 0;
    // start field bdt_tbl_id
    vl_api_u32_fromjson(item, &a->bdt_tbl_id);
    // end field bdt_tbl_id


    *len = l;
    return a;
}
static inline vl_api_bier_disp_entry_add_del_t *vl_api_bier_disp_entry_add_del_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_disp_entry_add_del_t);
    vl_api_bier_disp_entry_add_del_t *a = malloc(l);
    // processing bier_disp_entry_add_del: u16 bde_bp
    item = cJSON_GetObjectItem(o, "bde_bp");
    if (!item) return 0;
    // start field bde_bp
    vl_api_u16_fromjson(item, &a->bde_bp);
    // end field bde_bp

    // processing bier_disp_entry_add_del: u32 bde_tbl_id
    item = cJSON_GetObjectItem(o, "bde_tbl_id");
    if (!item) return 0;
    // start field bde_tbl_id
    vl_api_u32_fromjson(item, &a->bde_tbl_id);
    // end field bde_tbl_id

    // processing bier_disp_entry_add_del: bool bde_is_add
    item = cJSON_GetObjectItem(o, "bde_is_add");
    if (!item) return 0;
    // start field bde_is_add
    vl_api_bool_fromjson(item, &a->bde_is_add);
    // end field bde_is_add

    // processing bier_disp_entry_add_del: u8 bde_payload_proto
    item = cJSON_GetObjectItem(o, "bde_payload_proto");
    if (!item) return 0;
    // start field bde_payload_proto
    vl_api_u8_fromjson(item, &a->bde_payload_proto);
    // end field bde_payload_proto

    // processing bier_disp_entry_add_del: vl_api_fib_path_t bde_paths
    item = cJSON_GetObjectItem(o, "bde_paths");
    if (!item) return 0;
    {
        int i;
        cJSON *array = cJSON_GetObjectItem(o, "bde_paths");
        int size = cJSON_GetArraySize(array);
        a->bde_n_paths = size;
        a = realloc(a, l + sizeof(vl_api_fib_path_t) * size);
        vl_api_fib_path_t *d = (void *)a + l;
        l += sizeof(vl_api_fib_path_t) * size;
        for (i = 0; i < size; i++) {
            cJSON *e = cJSON_GetArrayItem(array, i);
            vl_api_fib_path_t_fromjson(a, len, e, &d[i]); 
        }
    }


    *len = l;
    return a;
}
static inline vl_api_bier_disp_entry_add_del_reply_t *vl_api_bier_disp_entry_add_del_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_disp_entry_add_del_reply_t);
    vl_api_bier_disp_entry_add_del_reply_t *a = malloc(l);
    // processing bier_disp_entry_add_del_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bier_disp_entry_dump_t *vl_api_bier_disp_entry_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_disp_entry_dump_t);
    vl_api_bier_disp_entry_dump_t *a = malloc(l);
    // processing bier_disp_entry_dump: u32 bde_tbl_id
    item = cJSON_GetObjectItem(o, "bde_tbl_id");
    if (!item) return 0;
    // start field bde_tbl_id
    vl_api_u32_fromjson(item, &a->bde_tbl_id);
    // end field bde_tbl_id


    *len = l;
    return a;
}
static inline vl_api_bier_disp_entry_details_t *vl_api_bier_disp_entry_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bier_disp_entry_details_t);
    vl_api_bier_disp_entry_details_t *a = malloc(l);
    // processing bier_disp_entry_details: u16 bde_bp
    item = cJSON_GetObjectItem(o, "bde_bp");
    if (!item) return 0;
    // start field bde_bp
    vl_api_u16_fromjson(item, &a->bde_bp);
    // end field bde_bp

    // processing bier_disp_entry_details: u32 bde_tbl_id
    item = cJSON_GetObjectItem(o, "bde_tbl_id");
    if (!item) return 0;
    // start field bde_tbl_id
    vl_api_u32_fromjson(item, &a->bde_tbl_id);
    // end field bde_tbl_id

    // processing bier_disp_entry_details: bool bde_is_add
    item = cJSON_GetObjectItem(o, "bde_is_add");
    if (!item) return 0;
    // start field bde_is_add
    vl_api_bool_fromjson(item, &a->bde_is_add);
    // end field bde_is_add

    // processing bier_disp_entry_details: u8 bde_payload_proto
    item = cJSON_GetObjectItem(o, "bde_payload_proto");
    if (!item) return 0;
    // start field bde_payload_proto
    vl_api_u8_fromjson(item, &a->bde_payload_proto);
    // end field bde_payload_proto

    // processing bier_disp_entry_details: vl_api_fib_path_t bde_paths
    item = cJSON_GetObjectItem(o, "bde_paths");
    if (!item) return 0;
    {
        int i;
        cJSON *array = cJSON_GetObjectItem(o, "bde_paths");
        int size = cJSON_GetArraySize(array);
        a->bde_n_paths = size;
        a = realloc(a, l + sizeof(vl_api_fib_path_t) * size);
        vl_api_fib_path_t *d = (void *)a + l;
        l += sizeof(vl_api_fib_path_t) * size;
        for (i = 0; i < size; i++) {
            cJSON *e = cJSON_GetArrayItem(array, i);
            vl_api_fib_path_t_fromjson(a, len, e, &d[i]); 
        }
    }


    *len = l;
    return a;
}
#endif
