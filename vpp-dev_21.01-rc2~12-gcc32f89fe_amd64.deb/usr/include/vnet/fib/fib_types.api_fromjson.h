/* Imported API files */
#include <vnet/ip/ip_types.api_fromjson.h>
#ifndef included_fib_types_api_fromjson_h
#define included_fib_types_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline void *vl_api_fib_mpls_label_t_fromjson (void *mp, int *len, cJSON *o, vl_api_fib_mpls_label_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "is_uniform");
    if (!item) return 0;
    // start field is_uniform
    vl_api_u8_fromjson(item, &a->is_uniform);
    // end field is_uniform
    item = cJSON_GetObjectItem(o, "label");
    if (!item) return 0;
    // start field label
    vl_api_u32_fromjson(item, &a->label);
    // end field label
    item = cJSON_GetObjectItem(o, "ttl");
    if (!item) return 0;
    // start field ttl
    vl_api_u8_fromjson(item, &a->ttl);
    // end field ttl
    item = cJSON_GetObjectItem(o, "exp");
    if (!item) return 0;
    // start field exp
    vl_api_u8_fromjson(item, &a->exp);
    // end field exp
    return mp;
}
static inline void *vl_api_fib_path_nh_proto_t_fromjson (void *mp, int *len, cJSON *o, vl_api_fib_path_nh_proto_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "FIB_API_PATH_NH_PROTO_IP4") == 0) {*a = 0; return mp;}
    if (strcmp(p, "FIB_API_PATH_NH_PROTO_IP6") == 0) {*a = 1; return mp;}
    if (strcmp(p, "FIB_API_PATH_NH_PROTO_MPLS") == 0) {*a = 2; return mp;}
    if (strcmp(p, "FIB_API_PATH_NH_PROTO_ETHERNET") == 0) {*a = 3; return mp;}
    if (strcmp(p, "FIB_API_PATH_NH_PROTO_BIER") == 0) {*a = 4; return mp;}
   return 0;
}
static inline void *vl_api_fib_path_flags_t_fromjson (void *mp, int *len, cJSON *o, vl_api_fib_path_flags_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "FIB_API_PATH_FLAG_NONE") == 0) {*a = 0; return mp;}
    if (strcmp(p, "FIB_API_PATH_FLAG_RESOLVE_VIA_ATTACHED") == 0) {*a = 1; return mp;}
    if (strcmp(p, "FIB_API_PATH_FLAG_RESOLVE_VIA_HOST") == 0) {*a = 2; return mp;}
    if (strcmp(p, "FIB_API_PATH_FLAG_POP_PW_CW") == 0) {*a = 4; return mp;}
   return 0;
}
static inline void *vl_api_fib_path_nh_t_fromjson (void *mp, int *len, cJSON *o, vl_api_fib_path_nh_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "address");
    if (!item) return 0;
    // start field address
    mp = vl_api_address_union_t_fromjson(mp, len, item, &a->address);
    if (!mp) return 0;
    // end field address
    item = cJSON_GetObjectItem(o, "via_label");
    if (!item) return 0;
    // start field via_label
    vl_api_u32_fromjson(item, &a->via_label);
    // end field via_label
    item = cJSON_GetObjectItem(o, "obj_id");
    if (!item) return 0;
    // start field obj_id
    vl_api_u32_fromjson(item, &a->obj_id);
    // end field obj_id
    item = cJSON_GetObjectItem(o, "classify_table_index");
    if (!item) return 0;
    // start field classify_table_index
    vl_api_u32_fromjson(item, &a->classify_table_index);
    // end field classify_table_index
    return mp;
}
static inline void *vl_api_fib_path_type_t_fromjson (void *mp, int *len, cJSON *o, vl_api_fib_path_type_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "FIB_API_PATH_TYPE_NORMAL") == 0) {*a = 0; return mp;}
    if (strcmp(p, "FIB_API_PATH_TYPE_LOCAL") == 0) {*a = 1; return mp;}
    if (strcmp(p, "FIB_API_PATH_TYPE_DROP") == 0) {*a = 2; return mp;}
    if (strcmp(p, "FIB_API_PATH_TYPE_UDP_ENCAP") == 0) {*a = 3; return mp;}
    if (strcmp(p, "FIB_API_PATH_TYPE_BIER_IMP") == 0) {*a = 4; return mp;}
    if (strcmp(p, "FIB_API_PATH_TYPE_ICMP_UNREACH") == 0) {*a = 5; return mp;}
    if (strcmp(p, "FIB_API_PATH_TYPE_ICMP_PROHIBIT") == 0) {*a = 6; return mp;}
    if (strcmp(p, "FIB_API_PATH_TYPE_SOURCE_LOOKUP") == 0) {*a = 7; return mp;}
    if (strcmp(p, "FIB_API_PATH_TYPE_DVR") == 0) {*a = 8; return mp;}
    if (strcmp(p, "FIB_API_PATH_TYPE_INTERFACE_RX") == 0) {*a = 9; return mp;}
    if (strcmp(p, "FIB_API_PATH_TYPE_CLASSIFY") == 0) {*a = 10; return mp;}
   return 0;
}
static inline void *vl_api_fib_path_t_fromjson (void *mp, int *len, cJSON *o, vl_api_fib_path_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    vl_api_u32_fromjson(item, &a->sw_if_index);
    // end field sw_if_index
    item = cJSON_GetObjectItem(o, "table_id");
    if (!item) return 0;
    // start field table_id
    vl_api_u32_fromjson(item, &a->table_id);
    // end field table_id
    item = cJSON_GetObjectItem(o, "rpf_id");
    if (!item) return 0;
    // start field rpf_id
    vl_api_u32_fromjson(item, &a->rpf_id);
    // end field rpf_id
    item = cJSON_GetObjectItem(o, "weight");
    if (!item) return 0;
    // start field weight
    vl_api_u8_fromjson(item, &a->weight);
    // end field weight
    item = cJSON_GetObjectItem(o, "preference");
    if (!item) return 0;
    // start field preference
    vl_api_u8_fromjson(item, &a->preference);
    // end field preference
    item = cJSON_GetObjectItem(o, "type");
    if (!item) return 0;
    // start field type
    mp = vl_api_fib_path_type_t_fromjson(mp, len, item, &a->type);
    if (!mp) return 0;
    // end field type
    item = cJSON_GetObjectItem(o, "flags");
    if (!item) return 0;
    // start field flags
    mp = vl_api_fib_path_flags_t_fromjson(mp, len, item, &a->flags);
    if (!mp) return 0;
    // end field flags
    item = cJSON_GetObjectItem(o, "proto");
    if (!item) return 0;
    // start field proto
    mp = vl_api_fib_path_nh_proto_t_fromjson(mp, len, item, &a->proto);
    if (!mp) return 0;
    // end field proto
    item = cJSON_GetObjectItem(o, "nh");
    if (!item) return 0;
    // start field nh
    mp = vl_api_fib_path_nh_t_fromjson(mp, len, item, &a->nh);
    if (!mp) return 0;
    // end field nh
    item = cJSON_GetObjectItem(o, "n_labels");
    if (!item) return 0;
    // start field n_labels
    vl_api_u8_fromjson(item, &a->n_labels);
    // end field n_labels
    item = cJSON_GetObjectItem(o, "label_stack");
    if (!item) return 0;
    {
        int i;
        cJSON *array = cJSON_GetObjectItem(o, "label_stack");
        int size = cJSON_GetArraySize(array);
        if (size != 16) return 0;
        for (i = 0; i < size; i++) {
            cJSON *e = cJSON_GetArrayItem(array, i);
            a = vl_api_fib_mpls_label_t_fromjson(mp, len, e, &a->label_stack[i]);
        }
    }
    return mp;
}
#endif
