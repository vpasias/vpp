/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#ifndef included_feature_api_fromjson_h
#define included_feature_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline vl_api_feature_enable_disable_t *vl_api_feature_enable_disable_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_feature_enable_disable_t);
    vl_api_feature_enable_disable_t *a = malloc(l);
    // processing feature_enable_disable: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing feature_enable_disable: bool enable
    item = cJSON_GetObjectItem(o, "enable");
    if (!item) return 0;
    // start field enable
    vl_api_bool_fromjson(item, &a->enable);
    // end field enable

    // processing feature_enable_disable: string arc_name
    item = cJSON_GetObjectItem(o, "arc_name");
    if (!item) return 0;
    strncpy_s((char *)a->arc_name, sizeof(a->arc_name), cJSON_GetStringValue(item), sizeof(a->arc_name) - 1);

    // processing feature_enable_disable: string feature_name
    item = cJSON_GetObjectItem(o, "feature_name");
    if (!item) return 0;
    strncpy_s((char *)a->feature_name, sizeof(a->feature_name), cJSON_GetStringValue(item), sizeof(a->feature_name) - 1);


    *len = l;
    return a;
}
static inline vl_api_feature_enable_disable_reply_t *vl_api_feature_enable_disable_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_feature_enable_disable_reply_t);
    vl_api_feature_enable_disable_reply_t *a = malloc(l);
    // processing feature_enable_disable_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
#endif
