#ifndef included_feature_api_enum_h
#define included_feature_api_enum_h
typedef enum {
   VL_API_FEATURE_ENABLE_DISABLE,
   VL_API_FEATURE_ENABLE_DISABLE_REPLY,
   VL_MSG_FEATURE_LAST
} vl_api_feature_enum_t;
#endif
