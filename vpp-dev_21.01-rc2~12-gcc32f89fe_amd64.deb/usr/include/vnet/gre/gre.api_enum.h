#ifndef included_gre_api_enum_h
#define included_gre_api_enum_h
typedef enum {
   VL_API_GRE_TUNNEL_ADD_DEL,
   VL_API_GRE_TUNNEL_ADD_DEL_REPLY,
   VL_API_GRE_TUNNEL_DUMP,
   VL_API_GRE_TUNNEL_DETAILS,
   VL_MSG_GRE_LAST
} vl_api_gre_enum_t;
#endif
