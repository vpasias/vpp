/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#include <vnet/tunnel/tunnel_types.api_fromjson.h>
#include <vnet/ip/ip_types.api_fromjson.h>
#ifndef included_gre_api_fromjson_h
#define included_gre_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline void *vl_api_gre_tunnel_type_t_fromjson (void *mp, int *len, cJSON *o, vl_api_gre_tunnel_type_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "GRE_API_TUNNEL_TYPE_L3") == 0) {*a = 0; return mp;}
    if (strcmp(p, "GRE_API_TUNNEL_TYPE_TEB") == 0) {*a = 1; return mp;}
    if (strcmp(p, "GRE_API_TUNNEL_TYPE_ERSPAN") == 0) {*a = 2; return mp;}
   return 0;
}
static inline void *vl_api_gre_tunnel_t_fromjson (void *mp, int *len, cJSON *o, vl_api_gre_tunnel_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "type");
    if (!item) return 0;
    // start field type
    mp = vl_api_gre_tunnel_type_t_fromjson(mp, len, item, &a->type);
    if (!mp) return 0;
    // end field type
    item = cJSON_GetObjectItem(o, "mode");
    if (!item) return 0;
    // start field mode
    mp = vl_api_tunnel_mode_t_fromjson(mp, len, item, &a->mode);
    if (!mp) return 0;
    // end field mode
    item = cJSON_GetObjectItem(o, "flags");
    if (!item) return 0;
    // start field flags
    mp = vl_api_tunnel_encap_decap_flags_t_fromjson(mp, len, item, &a->flags);
    if (!mp) return 0;
    // end field flags
    item = cJSON_GetObjectItem(o, "session_id");
    if (!item) return 0;
    // start field session_id
    vl_api_u16_fromjson(item, &a->session_id);
    // end field session_id
    item = cJSON_GetObjectItem(o, "instance");
    if (!item) return 0;
    // start field instance
    vl_api_u32_fromjson(item, &a->instance);
    // end field instance
    item = cJSON_GetObjectItem(o, "outer_table_id");
    if (!item) return 0;
    // start field outer_table_id
    vl_api_u32_fromjson(item, &a->outer_table_id);
    // end field outer_table_id
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    mp = vl_api_interface_index_t_fromjson(mp, len, item, &a->sw_if_index);
    if (!mp) return 0;
    // end field sw_if_index
    item = cJSON_GetObjectItem(o, "src");
    if (!item) return 0;
    // start field src
    mp = vl_api_address_t_fromjson(mp, len, item, &a->src);
    if (!mp) return 0;
    // end field src
    item = cJSON_GetObjectItem(o, "dst");
    if (!item) return 0;
    // start field dst
    mp = vl_api_address_t_fromjson(mp, len, item, &a->dst);
    if (!mp) return 0;
    // end field dst
    return mp;
}
static inline vl_api_gre_tunnel_add_del_t *vl_api_gre_tunnel_add_del_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_gre_tunnel_add_del_t);
    vl_api_gre_tunnel_add_del_t *a = malloc(l);
    // processing gre_tunnel_add_del: bool is_add
    item = cJSON_GetObjectItem(o, "is_add");
    if (!item) return 0;
    // start field is_add
    vl_api_bool_fromjson(item, &a->is_add);
    // end field is_add

    // processing gre_tunnel_add_del: vl_api_gre_tunnel_t tunnel
    item = cJSON_GetObjectItem(o, "tunnel");
    if (!item) return 0;
    // start field tunnel
    a = vl_api_gre_tunnel_t_fromjson(a, &l, item, &a->tunnel);
    if (!a) return 0;
    // end field tunnel


    *len = l;
    return a;
}
static inline vl_api_gre_tunnel_add_del_reply_t *vl_api_gre_tunnel_add_del_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_gre_tunnel_add_del_reply_t);
    vl_api_gre_tunnel_add_del_reply_t *a = malloc(l);
    // processing gre_tunnel_add_del_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing gre_tunnel_add_del_reply: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_gre_tunnel_dump_t *vl_api_gre_tunnel_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_gre_tunnel_dump_t);
    vl_api_gre_tunnel_dump_t *a = malloc(l);
    // processing gre_tunnel_dump: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_gre_tunnel_details_t *vl_api_gre_tunnel_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_gre_tunnel_details_t);
    vl_api_gre_tunnel_details_t *a = malloc(l);
    // processing gre_tunnel_details: vl_api_gre_tunnel_t tunnel
    item = cJSON_GetObjectItem(o, "tunnel");
    if (!item) return 0;
    // start field tunnel
    a = vl_api_gre_tunnel_t_fromjson(a, &l, item, &a->tunnel);
    if (!a) return 0;
    // end field tunnel


    *len = l;
    return a;
}
#endif
