/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#include <vnet/ip/ip_types.api_fromjson.h>
#ifndef included_bfd_api_fromjson_h
#define included_bfd_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline void *vl_api_bfd_state_t_fromjson (void *mp, int *len, cJSON *o, vl_api_bfd_state_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "BFD_STATE_API_ADMIN_DOWN") == 0) {*a = 0; return mp;}
    if (strcmp(p, "BFD_STATE_API_DOWN") == 0) {*a = 1; return mp;}
    if (strcmp(p, "BFD_STATE_API_INIT") == 0) {*a = 2; return mp;}
    if (strcmp(p, "BFD_STATE_API_UP") == 0) {*a = 3; return mp;}
   return 0;
}
static inline vl_api_bfd_udp_set_echo_source_t *vl_api_bfd_udp_set_echo_source_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_set_echo_source_t);
    vl_api_bfd_udp_set_echo_source_t *a = malloc(l);
    // processing bfd_udp_set_echo_source: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_set_echo_source_reply_t *vl_api_bfd_udp_set_echo_source_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_set_echo_source_reply_t);
    vl_api_bfd_udp_set_echo_source_reply_t *a = malloc(l);
    // processing bfd_udp_set_echo_source_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_del_echo_source_t *vl_api_bfd_udp_del_echo_source_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_del_echo_source_t);
    vl_api_bfd_udp_del_echo_source_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_bfd_udp_del_echo_source_reply_t *vl_api_bfd_udp_del_echo_source_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_del_echo_source_reply_t);
    vl_api_bfd_udp_del_echo_source_reply_t *a = malloc(l);
    // processing bfd_udp_del_echo_source_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_get_echo_source_t *vl_api_bfd_udp_get_echo_source_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_get_echo_source_t);
    vl_api_bfd_udp_get_echo_source_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_bfd_udp_get_echo_source_reply_t *vl_api_bfd_udp_get_echo_source_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_get_echo_source_reply_t);
    vl_api_bfd_udp_get_echo_source_reply_t *a = malloc(l);
    // processing bfd_udp_get_echo_source_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing bfd_udp_get_echo_source_reply: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing bfd_udp_get_echo_source_reply: bool is_set
    item = cJSON_GetObjectItem(o, "is_set");
    if (!item) return 0;
    // start field is_set
    vl_api_bool_fromjson(item, &a->is_set);
    // end field is_set

    // processing bfd_udp_get_echo_source_reply: bool have_usable_ip4
    item = cJSON_GetObjectItem(o, "have_usable_ip4");
    if (!item) return 0;
    // start field have_usable_ip4
    vl_api_bool_fromjson(item, &a->have_usable_ip4);
    // end field have_usable_ip4

    // processing bfd_udp_get_echo_source_reply: vl_api_ip4_address_t ip4_addr
    item = cJSON_GetObjectItem(o, "ip4_addr");
    if (!item) return 0;
    // start field ip4_addr
    a = vl_api_ip4_address_t_fromjson(a, &l, item, &a->ip4_addr);
    if (!a) return 0;
    // end field ip4_addr

    // processing bfd_udp_get_echo_source_reply: bool have_usable_ip6
    item = cJSON_GetObjectItem(o, "have_usable_ip6");
    if (!item) return 0;
    // start field have_usable_ip6
    vl_api_bool_fromjson(item, &a->have_usable_ip6);
    // end field have_usable_ip6

    // processing bfd_udp_get_echo_source_reply: vl_api_ip6_address_t ip6_addr
    item = cJSON_GetObjectItem(o, "ip6_addr");
    if (!item) return 0;
    // start field ip6_addr
    a = vl_api_ip6_address_t_fromjson(a, &l, item, &a->ip6_addr);
    if (!a) return 0;
    // end field ip6_addr


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_add_t *vl_api_bfd_udp_add_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_add_t);
    vl_api_bfd_udp_add_t *a = malloc(l);
    // processing bfd_udp_add: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing bfd_udp_add: u32 desired_min_tx
    item = cJSON_GetObjectItem(o, "desired_min_tx");
    if (!item) return 0;
    // start field desired_min_tx
    vl_api_u32_fromjson(item, &a->desired_min_tx);
    // end field desired_min_tx

    // processing bfd_udp_add: u32 required_min_rx
    item = cJSON_GetObjectItem(o, "required_min_rx");
    if (!item) return 0;
    // start field required_min_rx
    vl_api_u32_fromjson(item, &a->required_min_rx);
    // end field required_min_rx

    // processing bfd_udp_add: vl_api_address_t local_addr
    item = cJSON_GetObjectItem(o, "local_addr");
    if (!item) return 0;
    // start field local_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->local_addr);
    if (!a) return 0;
    // end field local_addr

    // processing bfd_udp_add: vl_api_address_t peer_addr
    item = cJSON_GetObjectItem(o, "peer_addr");
    if (!item) return 0;
    // start field peer_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->peer_addr);
    if (!a) return 0;
    // end field peer_addr

    // processing bfd_udp_add: u8 detect_mult
    item = cJSON_GetObjectItem(o, "detect_mult");
    if (!item) return 0;
    // start field detect_mult
    vl_api_u8_fromjson(item, &a->detect_mult);
    // end field detect_mult

    // processing bfd_udp_add: bool is_authenticated
    item = cJSON_GetObjectItem(o, "is_authenticated");
    if (!item) return 0;
    // start field is_authenticated
    vl_api_bool_fromjson(item, &a->is_authenticated);
    // end field is_authenticated

    // processing bfd_udp_add: u8 bfd_key_id
    item = cJSON_GetObjectItem(o, "bfd_key_id");
    if (!item) return 0;
    // start field bfd_key_id
    vl_api_u8_fromjson(item, &a->bfd_key_id);
    // end field bfd_key_id

    // processing bfd_udp_add: u32 conf_key_id
    item = cJSON_GetObjectItem(o, "conf_key_id");
    if (!item) return 0;
    // start field conf_key_id
    vl_api_u32_fromjson(item, &a->conf_key_id);
    // end field conf_key_id


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_add_reply_t *vl_api_bfd_udp_add_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_add_reply_t);
    vl_api_bfd_udp_add_reply_t *a = malloc(l);
    // processing bfd_udp_add_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_mod_t *vl_api_bfd_udp_mod_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_mod_t);
    vl_api_bfd_udp_mod_t *a = malloc(l);
    // processing bfd_udp_mod: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing bfd_udp_mod: u32 desired_min_tx
    item = cJSON_GetObjectItem(o, "desired_min_tx");
    if (!item) return 0;
    // start field desired_min_tx
    vl_api_u32_fromjson(item, &a->desired_min_tx);
    // end field desired_min_tx

    // processing bfd_udp_mod: u32 required_min_rx
    item = cJSON_GetObjectItem(o, "required_min_rx");
    if (!item) return 0;
    // start field required_min_rx
    vl_api_u32_fromjson(item, &a->required_min_rx);
    // end field required_min_rx

    // processing bfd_udp_mod: vl_api_address_t local_addr
    item = cJSON_GetObjectItem(o, "local_addr");
    if (!item) return 0;
    // start field local_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->local_addr);
    if (!a) return 0;
    // end field local_addr

    // processing bfd_udp_mod: vl_api_address_t peer_addr
    item = cJSON_GetObjectItem(o, "peer_addr");
    if (!item) return 0;
    // start field peer_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->peer_addr);
    if (!a) return 0;
    // end field peer_addr

    // processing bfd_udp_mod: u8 detect_mult
    item = cJSON_GetObjectItem(o, "detect_mult");
    if (!item) return 0;
    // start field detect_mult
    vl_api_u8_fromjson(item, &a->detect_mult);
    // end field detect_mult


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_mod_reply_t *vl_api_bfd_udp_mod_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_mod_reply_t);
    vl_api_bfd_udp_mod_reply_t *a = malloc(l);
    // processing bfd_udp_mod_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_del_t *vl_api_bfd_udp_del_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_del_t);
    vl_api_bfd_udp_del_t *a = malloc(l);
    // processing bfd_udp_del: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing bfd_udp_del: vl_api_address_t local_addr
    item = cJSON_GetObjectItem(o, "local_addr");
    if (!item) return 0;
    // start field local_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->local_addr);
    if (!a) return 0;
    // end field local_addr

    // processing bfd_udp_del: vl_api_address_t peer_addr
    item = cJSON_GetObjectItem(o, "peer_addr");
    if (!item) return 0;
    // start field peer_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->peer_addr);
    if (!a) return 0;
    // end field peer_addr


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_del_reply_t *vl_api_bfd_udp_del_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_del_reply_t);
    vl_api_bfd_udp_del_reply_t *a = malloc(l);
    // processing bfd_udp_del_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_session_dump_t *vl_api_bfd_udp_session_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_session_dump_t);
    vl_api_bfd_udp_session_dump_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_bfd_udp_session_details_t *vl_api_bfd_udp_session_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_session_details_t);
    vl_api_bfd_udp_session_details_t *a = malloc(l);
    // processing bfd_udp_session_details: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing bfd_udp_session_details: vl_api_address_t local_addr
    item = cJSON_GetObjectItem(o, "local_addr");
    if (!item) return 0;
    // start field local_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->local_addr);
    if (!a) return 0;
    // end field local_addr

    // processing bfd_udp_session_details: vl_api_address_t peer_addr
    item = cJSON_GetObjectItem(o, "peer_addr");
    if (!item) return 0;
    // start field peer_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->peer_addr);
    if (!a) return 0;
    // end field peer_addr

    // processing bfd_udp_session_details: vl_api_bfd_state_t state
    item = cJSON_GetObjectItem(o, "state");
    if (!item) return 0;
    // start field state
    a = vl_api_bfd_state_t_fromjson(a, &l, item, &a->state);
    if (!a) return 0;
    // end field state

    // processing bfd_udp_session_details: bool is_authenticated
    item = cJSON_GetObjectItem(o, "is_authenticated");
    if (!item) return 0;
    // start field is_authenticated
    vl_api_bool_fromjson(item, &a->is_authenticated);
    // end field is_authenticated

    // processing bfd_udp_session_details: u8 bfd_key_id
    item = cJSON_GetObjectItem(o, "bfd_key_id");
    if (!item) return 0;
    // start field bfd_key_id
    vl_api_u8_fromjson(item, &a->bfd_key_id);
    // end field bfd_key_id

    // processing bfd_udp_session_details: u32 conf_key_id
    item = cJSON_GetObjectItem(o, "conf_key_id");
    if (!item) return 0;
    // start field conf_key_id
    vl_api_u32_fromjson(item, &a->conf_key_id);
    // end field conf_key_id

    // processing bfd_udp_session_details: u32 required_min_rx
    item = cJSON_GetObjectItem(o, "required_min_rx");
    if (!item) return 0;
    // start field required_min_rx
    vl_api_u32_fromjson(item, &a->required_min_rx);
    // end field required_min_rx

    // processing bfd_udp_session_details: u32 desired_min_tx
    item = cJSON_GetObjectItem(o, "desired_min_tx");
    if (!item) return 0;
    // start field desired_min_tx
    vl_api_u32_fromjson(item, &a->desired_min_tx);
    // end field desired_min_tx

    // processing bfd_udp_session_details: u8 detect_mult
    item = cJSON_GetObjectItem(o, "detect_mult");
    if (!item) return 0;
    // start field detect_mult
    vl_api_u8_fromjson(item, &a->detect_mult);
    // end field detect_mult


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_session_set_flags_t *vl_api_bfd_udp_session_set_flags_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_session_set_flags_t);
    vl_api_bfd_udp_session_set_flags_t *a = malloc(l);
    // processing bfd_udp_session_set_flags: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing bfd_udp_session_set_flags: vl_api_address_t local_addr
    item = cJSON_GetObjectItem(o, "local_addr");
    if (!item) return 0;
    // start field local_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->local_addr);
    if (!a) return 0;
    // end field local_addr

    // processing bfd_udp_session_set_flags: vl_api_address_t peer_addr
    item = cJSON_GetObjectItem(o, "peer_addr");
    if (!item) return 0;
    // start field peer_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->peer_addr);
    if (!a) return 0;
    // end field peer_addr

    // processing bfd_udp_session_set_flags: vl_api_if_status_flags_t flags
    item = cJSON_GetObjectItem(o, "flags");
    if (!item) return 0;
    // start field flags
    a = vl_api_if_status_flags_t_fromjson(a, &l, item, &a->flags);
    if (!a) return 0;
    // end field flags


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_session_set_flags_reply_t *vl_api_bfd_udp_session_set_flags_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_session_set_flags_reply_t);
    vl_api_bfd_udp_session_set_flags_reply_t *a = malloc(l);
    // processing bfd_udp_session_set_flags_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_want_bfd_events_t *vl_api_want_bfd_events_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_want_bfd_events_t);
    vl_api_want_bfd_events_t *a = malloc(l);
    // processing want_bfd_events: bool enable_disable
    item = cJSON_GetObjectItem(o, "enable_disable");
    if (!item) return 0;
    // start field enable_disable
    vl_api_bool_fromjson(item, &a->enable_disable);
    // end field enable_disable

    // processing want_bfd_events: u32 pid
    item = cJSON_GetObjectItem(o, "pid");
    if (!item) return 0;
    // start field pid
    vl_api_u32_fromjson(item, &a->pid);
    // end field pid


    *len = l;
    return a;
}
static inline vl_api_want_bfd_events_reply_t *vl_api_want_bfd_events_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_want_bfd_events_reply_t);
    vl_api_want_bfd_events_reply_t *a = malloc(l);
    // processing want_bfd_events_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bfd_auth_set_key_t *vl_api_bfd_auth_set_key_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_auth_set_key_t);
    vl_api_bfd_auth_set_key_t *a = malloc(l);
    // processing bfd_auth_set_key: u32 conf_key_id
    item = cJSON_GetObjectItem(o, "conf_key_id");
    if (!item) return 0;
    // start field conf_key_id
    vl_api_u32_fromjson(item, &a->conf_key_id);
    // end field conf_key_id

    // processing bfd_auth_set_key: u8 key_len
    item = cJSON_GetObjectItem(o, "key_len");
    if (!item) return 0;
    // start field key_len
    vl_api_u8_fromjson(item, &a->key_len);
    // end field key_len

    // processing bfd_auth_set_key: u8 auth_type
    item = cJSON_GetObjectItem(o, "auth_type");
    if (!item) return 0;
    // start field auth_type
    vl_api_u8_fromjson(item, &a->auth_type);
    // end field auth_type

    // processing bfd_auth_set_key: u8 key
    item = cJSON_GetObjectItem(o, "key");
    if (!item) return 0;
    u8string_fromjson2(o, "key", a->key);


    *len = l;
    return a;
}
static inline vl_api_bfd_auth_set_key_reply_t *vl_api_bfd_auth_set_key_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_auth_set_key_reply_t);
    vl_api_bfd_auth_set_key_reply_t *a = malloc(l);
    // processing bfd_auth_set_key_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bfd_auth_del_key_t *vl_api_bfd_auth_del_key_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_auth_del_key_t);
    vl_api_bfd_auth_del_key_t *a = malloc(l);
    // processing bfd_auth_del_key: u32 conf_key_id
    item = cJSON_GetObjectItem(o, "conf_key_id");
    if (!item) return 0;
    // start field conf_key_id
    vl_api_u32_fromjson(item, &a->conf_key_id);
    // end field conf_key_id


    *len = l;
    return a;
}
static inline vl_api_bfd_auth_del_key_reply_t *vl_api_bfd_auth_del_key_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_auth_del_key_reply_t);
    vl_api_bfd_auth_del_key_reply_t *a = malloc(l);
    // processing bfd_auth_del_key_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bfd_auth_keys_dump_t *vl_api_bfd_auth_keys_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_auth_keys_dump_t);
    vl_api_bfd_auth_keys_dump_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_bfd_auth_keys_details_t *vl_api_bfd_auth_keys_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_auth_keys_details_t);
    vl_api_bfd_auth_keys_details_t *a = malloc(l);
    // processing bfd_auth_keys_details: u32 conf_key_id
    item = cJSON_GetObjectItem(o, "conf_key_id");
    if (!item) return 0;
    // start field conf_key_id
    vl_api_u32_fromjson(item, &a->conf_key_id);
    // end field conf_key_id

    // processing bfd_auth_keys_details: u32 use_count
    item = cJSON_GetObjectItem(o, "use_count");
    if (!item) return 0;
    // start field use_count
    vl_api_u32_fromjson(item, &a->use_count);
    // end field use_count

    // processing bfd_auth_keys_details: u8 auth_type
    item = cJSON_GetObjectItem(o, "auth_type");
    if (!item) return 0;
    // start field auth_type
    vl_api_u8_fromjson(item, &a->auth_type);
    // end field auth_type


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_auth_activate_t *vl_api_bfd_udp_auth_activate_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_auth_activate_t);
    vl_api_bfd_udp_auth_activate_t *a = malloc(l);
    // processing bfd_udp_auth_activate: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing bfd_udp_auth_activate: vl_api_address_t local_addr
    item = cJSON_GetObjectItem(o, "local_addr");
    if (!item) return 0;
    // start field local_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->local_addr);
    if (!a) return 0;
    // end field local_addr

    // processing bfd_udp_auth_activate: vl_api_address_t peer_addr
    item = cJSON_GetObjectItem(o, "peer_addr");
    if (!item) return 0;
    // start field peer_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->peer_addr);
    if (!a) return 0;
    // end field peer_addr

    // processing bfd_udp_auth_activate: bool is_delayed
    item = cJSON_GetObjectItem(o, "is_delayed");
    if (!item) return 0;
    // start field is_delayed
    vl_api_bool_fromjson(item, &a->is_delayed);
    // end field is_delayed

    // processing bfd_udp_auth_activate: u8 bfd_key_id
    item = cJSON_GetObjectItem(o, "bfd_key_id");
    if (!item) return 0;
    // start field bfd_key_id
    vl_api_u8_fromjson(item, &a->bfd_key_id);
    // end field bfd_key_id

    // processing bfd_udp_auth_activate: u32 conf_key_id
    item = cJSON_GetObjectItem(o, "conf_key_id");
    if (!item) return 0;
    // start field conf_key_id
    vl_api_u32_fromjson(item, &a->conf_key_id);
    // end field conf_key_id


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_auth_activate_reply_t *vl_api_bfd_udp_auth_activate_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_auth_activate_reply_t);
    vl_api_bfd_udp_auth_activate_reply_t *a = malloc(l);
    // processing bfd_udp_auth_activate_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_auth_deactivate_t *vl_api_bfd_udp_auth_deactivate_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_auth_deactivate_t);
    vl_api_bfd_udp_auth_deactivate_t *a = malloc(l);
    // processing bfd_udp_auth_deactivate: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing bfd_udp_auth_deactivate: vl_api_address_t local_addr
    item = cJSON_GetObjectItem(o, "local_addr");
    if (!item) return 0;
    // start field local_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->local_addr);
    if (!a) return 0;
    // end field local_addr

    // processing bfd_udp_auth_deactivate: vl_api_address_t peer_addr
    item = cJSON_GetObjectItem(o, "peer_addr");
    if (!item) return 0;
    // start field peer_addr
    a = vl_api_address_t_fromjson(a, &l, item, &a->peer_addr);
    if (!a) return 0;
    // end field peer_addr

    // processing bfd_udp_auth_deactivate: bool is_delayed
    item = cJSON_GetObjectItem(o, "is_delayed");
    if (!item) return 0;
    // start field is_delayed
    vl_api_bool_fromjson(item, &a->is_delayed);
    // end field is_delayed


    *len = l;
    return a;
}
static inline vl_api_bfd_udp_auth_deactivate_reply_t *vl_api_bfd_udp_auth_deactivate_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bfd_udp_auth_deactivate_reply_t);
    vl_api_bfd_udp_auth_deactivate_reply_t *a = malloc(l);
    // processing bfd_udp_auth_deactivate_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
#endif
