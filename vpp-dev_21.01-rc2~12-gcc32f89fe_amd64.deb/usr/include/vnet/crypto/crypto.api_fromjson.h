/* Imported API files */
#ifndef included_crypto_api_fromjson_h
#define included_crypto_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline void *vl_api_crypto_dispatch_mode_t_fromjson (void *mp, int *len, cJSON *o, vl_api_crypto_dispatch_mode_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "CRYPTO_ASYNC_DISPATCH_POLLING") == 0) {*a = 0; return mp;}
    if (strcmp(p, "CRYPTO_ASYNC_DISPATCH_INTERRUPT") == 0) {*a = 1; return mp;}
   return 0;
}
static inline void *vl_api_crypto_op_class_type_t_fromjson (void *mp, int *len, cJSON *o, vl_api_crypto_op_class_type_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "CRYPTO_API_OP_SIMPLE") == 0) {*a = 0; return mp;}
    if (strcmp(p, "CRYPTO_API_OP_CHAINED") == 0) {*a = 1; return mp;}
    if (strcmp(p, "CRYPTO_API_OP_BOTH") == 0) {*a = 2; return mp;}
   return 0;
}
static inline vl_api_crypto_set_async_dispatch_t *vl_api_crypto_set_async_dispatch_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_crypto_set_async_dispatch_t);
    vl_api_crypto_set_async_dispatch_t *a = malloc(l);
    // processing crypto_set_async_dispatch: vl_api_crypto_dispatch_mode_t mode
    item = cJSON_GetObjectItem(o, "mode");
    if (!item) return 0;
    // start field mode
    a = vl_api_crypto_dispatch_mode_t_fromjson(a, &l, item, &a->mode);
    if (!a) return 0;
    // end field mode


    *len = l;
    return a;
}
static inline vl_api_crypto_set_async_dispatch_reply_t *vl_api_crypto_set_async_dispatch_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_crypto_set_async_dispatch_reply_t);
    vl_api_crypto_set_async_dispatch_reply_t *a = malloc(l);
    // processing crypto_set_async_dispatch_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_crypto_set_handler_t *vl_api_crypto_set_handler_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_crypto_set_handler_t);
    vl_api_crypto_set_handler_t *a = malloc(l);
    // processing crypto_set_handler: string alg_name
    item = cJSON_GetObjectItem(o, "alg_name");
    if (!item) return 0;
    strncpy_s((char *)a->alg_name, sizeof(a->alg_name), cJSON_GetStringValue(item), sizeof(a->alg_name) - 1);

    // processing crypto_set_handler: string engine
    item = cJSON_GetObjectItem(o, "engine");
    if (!item) return 0;
    strncpy_s((char *)a->engine, sizeof(a->engine), cJSON_GetStringValue(item), sizeof(a->engine) - 1);

    // processing crypto_set_handler: vl_api_crypto_op_class_type_t oct
    item = cJSON_GetObjectItem(o, "oct");
    if (!item) return 0;
    // start field oct
    a = vl_api_crypto_op_class_type_t_fromjson(a, &l, item, &a->oct);
    if (!a) return 0;
    // end field oct

    // processing crypto_set_handler: u8 is_async
    item = cJSON_GetObjectItem(o, "is_async");
    if (!item) return 0;
    // start field is_async
    vl_api_u8_fromjson(item, &a->is_async);
    // end field is_async


    *len = l;
    return a;
}
static inline vl_api_crypto_set_handler_reply_t *vl_api_crypto_set_handler_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_crypto_set_handler_reply_t);
    vl_api_crypto_set_handler_reply_t *a = malloc(l);
    // processing crypto_set_handler_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
#endif
