/*
 * VLIB API definitions 2021-03-03 19:00:15
 * Input file: crypto.api
 * Automatically generated: please edit the input file NOT this file!
 */

#include <stdbool.h>
#if defined(vl_msg_id)||defined(vl_union_id) \
    || defined(vl_printfun) ||defined(vl_endianfun) \
    || defined(vl_api_version)||defined(vl_typedefs) \
    || defined(vl_msg_name)||defined(vl_msg_name_crc_list) \
    || defined(vl_api_version_tuple)
/* ok, something was selected */
#else
#warning no content included from crypto.api
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))
/* Imported API files */
#ifndef vl_api_version
#endif

/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_CRYPTO_SET_ASYNC_DISPATCH, vl_api_crypto_set_async_dispatch_t_handler)
vl_msg_id(VL_API_CRYPTO_SET_ASYNC_DISPATCH_REPLY, vl_api_crypto_set_async_dispatch_reply_t_handler)
vl_msg_id(VL_API_CRYPTO_SET_HANDLER, vl_api_crypto_set_handler_t_handler)
vl_msg_id(VL_API_CRYPTO_SET_HANDLER_REPLY, vl_api_crypto_set_handler_reply_t_handler)
#endif
/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_crypto_set_async_dispatch_t, 1)
vl_msg_name(vl_api_crypto_set_async_dispatch_reply_t, 1)
vl_msg_name(vl_api_crypto_set_handler_t, 1)
vl_msg_name(vl_api_crypto_set_handler_reply_t, 1)
#endif
/****** Message name, crc list ******/

#ifdef vl_msg_name_crc_list
#define foreach_vl_msg_name_crc_crypto \
_(VL_API_CRYPTO_SET_ASYNC_DISPATCH, crypto_set_async_dispatch, 5ca4adc0) \
_(VL_API_CRYPTO_SET_ASYNC_DISPATCH_REPLY, crypto_set_async_dispatch_reply, e8d4e804) \
_(VL_API_CRYPTO_SET_HANDLER, crypto_set_handler, ce9ad00d) \
_(VL_API_CRYPTO_SET_HANDLER_REPLY, crypto_set_handler_reply, e8d4e804) 
#endif
/****** Typedefs ******/

#ifdef vl_typedefs
#include "crypto.api_types.h"
#endif
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_crypto_printfun_types
#define included_crypto_printfun_types

static inline u8 *format_vl_api_crypto_dispatch_mode_t (u8 *s, va_list * args)
{
    vl_api_crypto_dispatch_mode_t *a = va_arg (*args, vl_api_crypto_dispatch_mode_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    switch(*a) {
    case 0:
        return format(s, "CRYPTO_ASYNC_DISPATCH_POLLING");
    case 1:
        return format(s, "CRYPTO_ASYNC_DISPATCH_INTERRUPT");
    }
    return s;
}

static inline u8 *format_vl_api_crypto_op_class_type_t (u8 *s, va_list * args)
{
    vl_api_crypto_op_class_type_t *a = va_arg (*args, vl_api_crypto_op_class_type_t *);
    u32 indent __attribute__((unused)) = va_arg (*args, u32);
    int i __attribute__((unused));
    indent += 2;
    switch(*a) {
    case 0:
        return format(s, "CRYPTO_API_OP_SIMPLE");
    case 1:
        return format(s, "CRYPTO_API_OP_CHAINED");
    case 2:
        return format(s, "CRYPTO_API_OP_BOTH");
    }
    return s;
}


#endif
#endif /* vl_printfun_types */
/****** Print functions *****/
#ifdef vl_printfun
#ifndef included_crypto_printfun
#define included_crypto_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

static inline void *vl_api_crypto_set_async_dispatch_t_print (vl_api_crypto_set_async_dispatch_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_crypto_set_async_dispatch_t: */
    s = format(s, "vl_api_crypto_set_async_dispatch_t:");
    s = format(s, "\n%Umode: %U", format_white_space, indent, format_vl_api_crypto_dispatch_mode_t, &a->mode, indent);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_crypto_set_async_dispatch_reply_t_print (vl_api_crypto_set_async_dispatch_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_crypto_set_async_dispatch_reply_t: */
    s = format(s, "vl_api_crypto_set_async_dispatch_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_crypto_set_handler_t_print (vl_api_crypto_set_handler_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_crypto_set_handler_t: */
    s = format(s, "vl_api_crypto_set_handler_t:");
    s = format(s, "\n%Ualg_name: %s", format_white_space, indent, a->alg_name);
    s = format(s, "\n%Uengine: %s", format_white_space, indent, a->engine);
    s = format(s, "\n%Uoct: %U", format_white_space, indent, format_vl_api_crypto_op_class_type_t, &a->oct, indent);
    s = format(s, "\n%Uis_async: %u", format_white_space, indent, a->is_async);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}

static inline void *vl_api_crypto_set_handler_reply_t_print (vl_api_crypto_set_handler_reply_t *a, void *handle)
{
    u8 *s = 0;
    u32 indent __attribute__((unused)) = 2;
    int i __attribute__((unused));
    /* Message definition: vl_api_crypto_set_handler_reply_t: */
    s = format(s, "vl_api_crypto_set_handler_reply_t:");
    s = format(s, "\n%Uretval: %ld", format_white_space, indent, a->retval);
    vec_add1(s, 0);
    vl_print (handle, (char *)s);
    vec_free (s);
    return handle;
}


#endif
#endif /* vl_printfun */

/****** Endian swap functions *****/
#ifdef vl_endianfun
#ifndef included_crypto_endianfun
#define included_crypto_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_crypto_dispatch_mode_t_endian (vl_api_crypto_dispatch_mode_t *a)
{
    int i __attribute__((unused));
    /* a->crypto_dispatch_mode = a->crypto_dispatch_mode (no-op) */
}

static inline void vl_api_crypto_op_class_type_t_endian (vl_api_crypto_op_class_type_t *a)
{
    int i __attribute__((unused));
    /* a->crypto_op_class_type = a->crypto_op_class_type (no-op) */
}

static inline void vl_api_crypto_set_async_dispatch_t_endian (vl_api_crypto_set_async_dispatch_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
    vl_api_crypto_dispatch_mode_t_endian(&a->mode);
}

static inline void vl_api_crypto_set_async_dispatch_reply_t_endian (vl_api_crypto_set_async_dispatch_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_i32(a->retval);
}

static inline void vl_api_crypto_set_handler_t_endian (vl_api_crypto_set_handler_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    /* a->client_index = a->client_index (no-op) */
    a->context = clib_net_to_host_u32(a->context);
    /* a->alg_name = a->alg_name (no-op) */
    /* a->engine = a->engine (no-op) */
    vl_api_crypto_op_class_type_t_endian(&a->oct);
    /* a->is_async = a->is_async (no-op) */
}

static inline void vl_api_crypto_set_handler_reply_t_endian (vl_api_crypto_set_handler_reply_t *a)
{
    int i __attribute__((unused));
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_i32(a->retval);
}


#endif
#endif /* vl_endianfun */

/****** Version tuple *****/

#ifdef vl_api_version_tuple

vl_api_version_tuple(crypto.api, 1, 0, 1)

#endif /* vl_api_version_tuple */

/****** API CRC (whole file) *****/

#ifdef vl_api_version
vl_api_version(crypto.api, 0x22355ec6)

#endif

