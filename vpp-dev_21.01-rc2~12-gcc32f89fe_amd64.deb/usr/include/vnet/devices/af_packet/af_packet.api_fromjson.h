/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#include <vnet/ethernet/ethernet_types.api_fromjson.h>
#ifndef included_af_packet_api_fromjson_h
#define included_af_packet_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline vl_api_af_packet_create_t *vl_api_af_packet_create_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_af_packet_create_t);
    vl_api_af_packet_create_t *a = malloc(l);
    // processing af_packet_create: vl_api_mac_address_t hw_addr
    item = cJSON_GetObjectItem(o, "hw_addr");
    if (!item) return 0;
    // start field hw_addr
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->hw_addr);
    if (!a) return 0;
    // end field hw_addr

    // processing af_packet_create: bool use_random_hw_addr
    item = cJSON_GetObjectItem(o, "use_random_hw_addr");
    if (!item) return 0;
    // start field use_random_hw_addr
    vl_api_bool_fromjson(item, &a->use_random_hw_addr);
    // end field use_random_hw_addr

    // processing af_packet_create: string host_if_name
    item = cJSON_GetObjectItem(o, "host_if_name");
    if (!item) return 0;
    strncpy_s((char *)a->host_if_name, sizeof(a->host_if_name), cJSON_GetStringValue(item), sizeof(a->host_if_name) - 1);


    *len = l;
    return a;
}
static inline vl_api_af_packet_create_reply_t *vl_api_af_packet_create_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_af_packet_create_reply_t);
    vl_api_af_packet_create_reply_t *a = malloc(l);
    // processing af_packet_create_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing af_packet_create_reply: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_af_packet_delete_t *vl_api_af_packet_delete_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_af_packet_delete_t);
    vl_api_af_packet_delete_t *a = malloc(l);
    // processing af_packet_delete: string host_if_name
    item = cJSON_GetObjectItem(o, "host_if_name");
    if (!item) return 0;
    strncpy_s((char *)a->host_if_name, sizeof(a->host_if_name), cJSON_GetStringValue(item), sizeof(a->host_if_name) - 1);


    *len = l;
    return a;
}
static inline vl_api_af_packet_delete_reply_t *vl_api_af_packet_delete_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_af_packet_delete_reply_t);
    vl_api_af_packet_delete_reply_t *a = malloc(l);
    // processing af_packet_delete_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_af_packet_set_l4_cksum_offload_t *vl_api_af_packet_set_l4_cksum_offload_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_af_packet_set_l4_cksum_offload_t);
    vl_api_af_packet_set_l4_cksum_offload_t *a = malloc(l);
    // processing af_packet_set_l4_cksum_offload: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing af_packet_set_l4_cksum_offload: bool set
    item = cJSON_GetObjectItem(o, "set");
    if (!item) return 0;
    // start field set
    vl_api_bool_fromjson(item, &a->set);
    // end field set


    *len = l;
    return a;
}
static inline vl_api_af_packet_set_l4_cksum_offload_reply_t *vl_api_af_packet_set_l4_cksum_offload_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_af_packet_set_l4_cksum_offload_reply_t);
    vl_api_af_packet_set_l4_cksum_offload_reply_t *a = malloc(l);
    // processing af_packet_set_l4_cksum_offload_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_af_packet_dump_t *vl_api_af_packet_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_af_packet_dump_t);
    vl_api_af_packet_dump_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_af_packet_details_t *vl_api_af_packet_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_af_packet_details_t);
    vl_api_af_packet_details_t *a = malloc(l);
    // processing af_packet_details: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing af_packet_details: string host_if_name
    item = cJSON_GetObjectItem(o, "host_if_name");
    if (!item) return 0;
    strncpy_s((char *)a->host_if_name, sizeof(a->host_if_name), cJSON_GetStringValue(item), sizeof(a->host_if_name) - 1);


    *len = l;
    return a;
}
#endif
