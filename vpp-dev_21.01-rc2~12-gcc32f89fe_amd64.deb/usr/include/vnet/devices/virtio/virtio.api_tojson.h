/* Imported API files */
#include <vnet/interface_types.api_tojson.h>
#include <vnet/ethernet/ethernet_types.api_tojson.h>
#include <vlib/pci/pci_types.api_tojson.h>
#ifndef included_virtio_api_tojson_h
#define included_virtio_api_tojson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline cJSON *vl_api_virtio_flags_t_tojson (vl_api_virtio_flags_t a) {
    switch(a) {
    case 1:
        return cJSON_CreateString("VIRTIO_API_FLAG_GSO");
    case 2:
        return cJSON_CreateString("VIRTIO_API_FLAG_CSUM_OFFLOAD");
    case 4:
        return cJSON_CreateString("VIRTIO_API_FLAG_GRO_COALESCE");
    case 8:
        return cJSON_CreateString("VIRTIO_API_FLAG_PACKED");
    case 16:
        return cJSON_CreateString("VIRTIO_API_FLAG_IN_ORDER");
    case 32:
        return cJSON_CreateString("VIRTIO_API_FLAG_BUFFERING");
    default: return cJSON_CreateString("Invalid ENUM");
    }
    return 0;
}
static inline cJSON *vl_api_virtio_pci_create_t_tojson (vl_api_virtio_pci_create_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "virtio_pci_create");
    cJSON_AddItemToObject(o, "pci_addr", vl_api_pci_address_t_tojson(&a->pci_addr));
    cJSON_AddBoolToObject(o, "use_random_mac", a->use_random_mac);
    cJSON_AddItemToObject(o, "mac_address", vl_api_mac_address_t_tojson(&a->mac_address));
    cJSON_AddBoolToObject(o, "gso_enabled", a->gso_enabled);
    cJSON_AddBoolToObject(o, "checksum_offload_enabled", a->checksum_offload_enabled);
    cJSON_AddNumberToObject(o, "features", a->features);
    return o;
}
static inline cJSON *vl_api_virtio_pci_create_reply_t_tojson (vl_api_virtio_pci_create_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "virtio_pci_create_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    cJSON_AddNumberToObject(o, "sw_if_index", a->sw_if_index);
    return o;
}
static inline cJSON *vl_api_virtio_pci_create_v2_t_tojson (vl_api_virtio_pci_create_v2_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "virtio_pci_create_v2");
    cJSON_AddItemToObject(o, "pci_addr", vl_api_pci_address_t_tojson(&a->pci_addr));
    cJSON_AddBoolToObject(o, "use_random_mac", a->use_random_mac);
    cJSON_AddItemToObject(o, "mac_address", vl_api_mac_address_t_tojson(&a->mac_address));
    cJSON_AddItemToObject(o, "virtio_flags", vl_api_virtio_flags_t_tojson(a->virtio_flags));
    cJSON_AddNumberToObject(o, "features", a->features);
    return o;
}
static inline cJSON *vl_api_virtio_pci_create_v2_reply_t_tojson (vl_api_virtio_pci_create_v2_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "virtio_pci_create_v2_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    cJSON_AddNumberToObject(o, "sw_if_index", a->sw_if_index);
    return o;
}
static inline cJSON *vl_api_virtio_pci_delete_t_tojson (vl_api_virtio_pci_delete_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "virtio_pci_delete");
    cJSON_AddNumberToObject(o, "sw_if_index", a->sw_if_index);
    return o;
}
static inline cJSON *vl_api_virtio_pci_delete_reply_t_tojson (vl_api_virtio_pci_delete_reply_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "virtio_pci_delete_reply");
    cJSON_AddNumberToObject(o, "retval", a->retval);
    return o;
}
static inline cJSON *vl_api_sw_interface_virtio_pci_dump_t_tojson (vl_api_sw_interface_virtio_pci_dump_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "sw_interface_virtio_pci_dump");
    return o;
}
static inline cJSON *vl_api_sw_interface_virtio_pci_details_t_tojson (vl_api_sw_interface_virtio_pci_details_t *a) {
    cJSON *o = cJSON_CreateObject();
    cJSON_AddStringToObject(o, "_msgname", "sw_interface_virtio_pci_details");
    cJSON_AddNumberToObject(o, "sw_if_index", a->sw_if_index);
    cJSON_AddItemToObject(o, "pci_addr", vl_api_pci_address_t_tojson(&a->pci_addr));
    cJSON_AddItemToObject(o, "mac_addr", vl_api_mac_address_t_tojson(&a->mac_addr));
    cJSON_AddNumberToObject(o, "tx_ring_sz", a->tx_ring_sz);
    cJSON_AddNumberToObject(o, "rx_ring_sz", a->rx_ring_sz);
    cJSON_AddNumberToObject(o, "features", a->features);
    return o;
}
#endif
