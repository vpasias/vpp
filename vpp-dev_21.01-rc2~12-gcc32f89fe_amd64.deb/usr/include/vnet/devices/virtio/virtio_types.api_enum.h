#ifndef included_virtio_types_api_enum_h
#define included_virtio_types_api_enum_h
typedef enum {
   VL_MSG_VIRTIO_TYPES_LAST
} vl_api_virtio_types_enum_t;
#endif
