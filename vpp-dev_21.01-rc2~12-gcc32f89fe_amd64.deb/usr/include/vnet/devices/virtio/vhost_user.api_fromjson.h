/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#include <vnet/ethernet/ethernet_types.api_fromjson.h>
#include <vnet/devices/virtio/virtio_types.api_fromjson.h>
#ifndef included_vhost_user_api_fromjson_h
#define included_vhost_user_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline vl_api_create_vhost_user_if_t *vl_api_create_vhost_user_if_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_create_vhost_user_if_t);
    vl_api_create_vhost_user_if_t *a = malloc(l);
    // processing create_vhost_user_if: bool is_server
    item = cJSON_GetObjectItem(o, "is_server");
    if (!item) return 0;
    // start field is_server
    vl_api_bool_fromjson(item, &a->is_server);
    // end field is_server

    // processing create_vhost_user_if: string sock_filename
    item = cJSON_GetObjectItem(o, "sock_filename");
    if (!item) return 0;
    strncpy_s((char *)a->sock_filename, sizeof(a->sock_filename), cJSON_GetStringValue(item), sizeof(a->sock_filename) - 1);

    // processing create_vhost_user_if: bool renumber
    item = cJSON_GetObjectItem(o, "renumber");
    if (!item) return 0;
    // start field renumber
    vl_api_bool_fromjson(item, &a->renumber);
    // end field renumber

    // processing create_vhost_user_if: bool disable_mrg_rxbuf
    item = cJSON_GetObjectItem(o, "disable_mrg_rxbuf");
    if (!item) return 0;
    // start field disable_mrg_rxbuf
    vl_api_bool_fromjson(item, &a->disable_mrg_rxbuf);
    // end field disable_mrg_rxbuf

    // processing create_vhost_user_if: bool disable_indirect_desc
    item = cJSON_GetObjectItem(o, "disable_indirect_desc");
    if (!item) return 0;
    // start field disable_indirect_desc
    vl_api_bool_fromjson(item, &a->disable_indirect_desc);
    // end field disable_indirect_desc

    // processing create_vhost_user_if: bool enable_gso
    item = cJSON_GetObjectItem(o, "enable_gso");
    if (!item) return 0;
    // start field enable_gso
    vl_api_bool_fromjson(item, &a->enable_gso);
    // end field enable_gso

    // processing create_vhost_user_if: bool enable_packed
    item = cJSON_GetObjectItem(o, "enable_packed");
    if (!item) return 0;
    // start field enable_packed
    vl_api_bool_fromjson(item, &a->enable_packed);
    // end field enable_packed

    // processing create_vhost_user_if: u32 custom_dev_instance
    item = cJSON_GetObjectItem(o, "custom_dev_instance");
    if (!item) return 0;
    // start field custom_dev_instance
    vl_api_u32_fromjson(item, &a->custom_dev_instance);
    // end field custom_dev_instance

    // processing create_vhost_user_if: bool use_custom_mac
    item = cJSON_GetObjectItem(o, "use_custom_mac");
    if (!item) return 0;
    // start field use_custom_mac
    vl_api_bool_fromjson(item, &a->use_custom_mac);
    // end field use_custom_mac

    // processing create_vhost_user_if: vl_api_mac_address_t mac_address
    item = cJSON_GetObjectItem(o, "mac_address");
    if (!item) return 0;
    // start field mac_address
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->mac_address);
    if (!a) return 0;
    // end field mac_address

    // processing create_vhost_user_if: string tag
    item = cJSON_GetObjectItem(o, "tag");
    if (!item) return 0;
    strncpy_s((char *)a->tag, sizeof(a->tag), cJSON_GetStringValue(item), sizeof(a->tag) - 1);


    *len = l;
    return a;
}
static inline vl_api_create_vhost_user_if_reply_t *vl_api_create_vhost_user_if_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_create_vhost_user_if_reply_t);
    vl_api_create_vhost_user_if_reply_t *a = malloc(l);
    // processing create_vhost_user_if_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing create_vhost_user_if_reply: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_modify_vhost_user_if_t *vl_api_modify_vhost_user_if_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_modify_vhost_user_if_t);
    vl_api_modify_vhost_user_if_t *a = malloc(l);
    // processing modify_vhost_user_if: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing modify_vhost_user_if: bool is_server
    item = cJSON_GetObjectItem(o, "is_server");
    if (!item) return 0;
    // start field is_server
    vl_api_bool_fromjson(item, &a->is_server);
    // end field is_server

    // processing modify_vhost_user_if: string sock_filename
    item = cJSON_GetObjectItem(o, "sock_filename");
    if (!item) return 0;
    strncpy_s((char *)a->sock_filename, sizeof(a->sock_filename), cJSON_GetStringValue(item), sizeof(a->sock_filename) - 1);

    // processing modify_vhost_user_if: bool renumber
    item = cJSON_GetObjectItem(o, "renumber");
    if (!item) return 0;
    // start field renumber
    vl_api_bool_fromjson(item, &a->renumber);
    // end field renumber

    // processing modify_vhost_user_if: bool enable_gso
    item = cJSON_GetObjectItem(o, "enable_gso");
    if (!item) return 0;
    // start field enable_gso
    vl_api_bool_fromjson(item, &a->enable_gso);
    // end field enable_gso

    // processing modify_vhost_user_if: bool enable_packed
    item = cJSON_GetObjectItem(o, "enable_packed");
    if (!item) return 0;
    // start field enable_packed
    vl_api_bool_fromjson(item, &a->enable_packed);
    // end field enable_packed

    // processing modify_vhost_user_if: u32 custom_dev_instance
    item = cJSON_GetObjectItem(o, "custom_dev_instance");
    if (!item) return 0;
    // start field custom_dev_instance
    vl_api_u32_fromjson(item, &a->custom_dev_instance);
    // end field custom_dev_instance


    *len = l;
    return a;
}
static inline vl_api_modify_vhost_user_if_reply_t *vl_api_modify_vhost_user_if_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_modify_vhost_user_if_reply_t);
    vl_api_modify_vhost_user_if_reply_t *a = malloc(l);
    // processing modify_vhost_user_if_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_delete_vhost_user_if_t *vl_api_delete_vhost_user_if_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_delete_vhost_user_if_t);
    vl_api_delete_vhost_user_if_t *a = malloc(l);
    // processing delete_vhost_user_if: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_delete_vhost_user_if_reply_t *vl_api_delete_vhost_user_if_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_delete_vhost_user_if_reply_t);
    vl_api_delete_vhost_user_if_reply_t *a = malloc(l);
    // processing delete_vhost_user_if_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_sw_interface_vhost_user_details_t *vl_api_sw_interface_vhost_user_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_vhost_user_details_t);
    vl_api_sw_interface_vhost_user_details_t *a = malloc(l);
    // processing sw_interface_vhost_user_details: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing sw_interface_vhost_user_details: string interface_name
    item = cJSON_GetObjectItem(o, "interface_name");
    if (!item) return 0;
    strncpy_s((char *)a->interface_name, sizeof(a->interface_name), cJSON_GetStringValue(item), sizeof(a->interface_name) - 1);

    // processing sw_interface_vhost_user_details: u32 virtio_net_hdr_sz
    item = cJSON_GetObjectItem(o, "virtio_net_hdr_sz");
    if (!item) return 0;
    // start field virtio_net_hdr_sz
    vl_api_u32_fromjson(item, &a->virtio_net_hdr_sz);
    // end field virtio_net_hdr_sz

    // processing sw_interface_vhost_user_details: vl_api_virtio_net_features_first_32_t features_first_32
    item = cJSON_GetObjectItem(o, "features_first_32");
    if (!item) return 0;
    // start field features_first_32
    a = vl_api_virtio_net_features_first_32_t_fromjson(a, &l, item, &a->features_first_32);
    if (!a) return 0;
    // end field features_first_32

    // processing sw_interface_vhost_user_details: vl_api_virtio_net_features_last_32_t features_last_32
    item = cJSON_GetObjectItem(o, "features_last_32");
    if (!item) return 0;
    // start field features_last_32
    a = vl_api_virtio_net_features_last_32_t_fromjson(a, &l, item, &a->features_last_32);
    if (!a) return 0;
    // end field features_last_32

    // processing sw_interface_vhost_user_details: bool is_server
    item = cJSON_GetObjectItem(o, "is_server");
    if (!item) return 0;
    // start field is_server
    vl_api_bool_fromjson(item, &a->is_server);
    // end field is_server

    // processing sw_interface_vhost_user_details: string sock_filename
    item = cJSON_GetObjectItem(o, "sock_filename");
    if (!item) return 0;
    strncpy_s((char *)a->sock_filename, sizeof(a->sock_filename), cJSON_GetStringValue(item), sizeof(a->sock_filename) - 1);

    // processing sw_interface_vhost_user_details: u32 num_regions
    item = cJSON_GetObjectItem(o, "num_regions");
    if (!item) return 0;
    // start field num_regions
    vl_api_u32_fromjson(item, &a->num_regions);
    // end field num_regions

    // processing sw_interface_vhost_user_details: i32 sock_errno
    item = cJSON_GetObjectItem(o, "sock_errno");
    if (!item) return 0;
    // start field sock_errno
    vl_api_i32_fromjson(item, &a->sock_errno);
    // end field sock_errno


    *len = l;
    return a;
}
static inline vl_api_sw_interface_vhost_user_dump_t *vl_api_sw_interface_vhost_user_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_vhost_user_dump_t);
    vl_api_sw_interface_vhost_user_dump_t *a = malloc(l);
    // processing sw_interface_vhost_user_dump: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
#endif
