/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#include <vnet/ethernet/ethernet_types.api_fromjson.h>
#include <vlib/pci/pci_types.api_fromjson.h>
#ifndef included_virtio_api_fromjson_h
#define included_virtio_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline void *vl_api_virtio_flags_t_fromjson (void *mp, int *len, cJSON *o, vl_api_virtio_flags_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "VIRTIO_API_FLAG_GSO") == 0) {*a = 1; return mp;}
    if (strcmp(p, "VIRTIO_API_FLAG_CSUM_OFFLOAD") == 0) {*a = 2; return mp;}
    if (strcmp(p, "VIRTIO_API_FLAG_GRO_COALESCE") == 0) {*a = 4; return mp;}
    if (strcmp(p, "VIRTIO_API_FLAG_PACKED") == 0) {*a = 8; return mp;}
    if (strcmp(p, "VIRTIO_API_FLAG_IN_ORDER") == 0) {*a = 16; return mp;}
    if (strcmp(p, "VIRTIO_API_FLAG_BUFFERING") == 0) {*a = 32; return mp;}
   return 0;
}
static inline vl_api_virtio_pci_create_t *vl_api_virtio_pci_create_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_virtio_pci_create_t);
    vl_api_virtio_pci_create_t *a = malloc(l);
    // processing virtio_pci_create: vl_api_pci_address_t pci_addr
    item = cJSON_GetObjectItem(o, "pci_addr");
    if (!item) return 0;
    // start field pci_addr
    a = vl_api_pci_address_t_fromjson(a, &l, item, &a->pci_addr);
    if (!a) return 0;
    // end field pci_addr

    // processing virtio_pci_create: bool use_random_mac
    item = cJSON_GetObjectItem(o, "use_random_mac");
    if (!item) return 0;
    // start field use_random_mac
    vl_api_bool_fromjson(item, &a->use_random_mac);
    // end field use_random_mac

    // processing virtio_pci_create: vl_api_mac_address_t mac_address
    item = cJSON_GetObjectItem(o, "mac_address");
    if (!item) return 0;
    // start field mac_address
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->mac_address);
    if (!a) return 0;
    // end field mac_address

    // processing virtio_pci_create: bool gso_enabled
    item = cJSON_GetObjectItem(o, "gso_enabled");
    if (!item) return 0;
    // start field gso_enabled
    vl_api_bool_fromjson(item, &a->gso_enabled);
    // end field gso_enabled

    // processing virtio_pci_create: bool checksum_offload_enabled
    item = cJSON_GetObjectItem(o, "checksum_offload_enabled");
    if (!item) return 0;
    // start field checksum_offload_enabled
    vl_api_bool_fromjson(item, &a->checksum_offload_enabled);
    // end field checksum_offload_enabled

    // processing virtio_pci_create: u64 features
    item = cJSON_GetObjectItem(o, "features");
    if (!item) return 0;
    // start field features
    vl_api_u64_fromjson(item, &a->features);
    // end field features


    *len = l;
    return a;
}
static inline vl_api_virtio_pci_create_reply_t *vl_api_virtio_pci_create_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_virtio_pci_create_reply_t);
    vl_api_virtio_pci_create_reply_t *a = malloc(l);
    // processing virtio_pci_create_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing virtio_pci_create_reply: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_virtio_pci_create_v2_t *vl_api_virtio_pci_create_v2_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_virtio_pci_create_v2_t);
    vl_api_virtio_pci_create_v2_t *a = malloc(l);
    // processing virtio_pci_create_v2: vl_api_pci_address_t pci_addr
    item = cJSON_GetObjectItem(o, "pci_addr");
    if (!item) return 0;
    // start field pci_addr
    a = vl_api_pci_address_t_fromjson(a, &l, item, &a->pci_addr);
    if (!a) return 0;
    // end field pci_addr

    // processing virtio_pci_create_v2: bool use_random_mac
    item = cJSON_GetObjectItem(o, "use_random_mac");
    if (!item) return 0;
    // start field use_random_mac
    vl_api_bool_fromjson(item, &a->use_random_mac);
    // end field use_random_mac

    // processing virtio_pci_create_v2: vl_api_mac_address_t mac_address
    item = cJSON_GetObjectItem(o, "mac_address");
    if (!item) return 0;
    // start field mac_address
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->mac_address);
    if (!a) return 0;
    // end field mac_address

    // processing virtio_pci_create_v2: vl_api_virtio_flags_t virtio_flags
    item = cJSON_GetObjectItem(o, "virtio_flags");
    if (!item) return 0;
    // start field virtio_flags
    a = vl_api_virtio_flags_t_fromjson(a, &l, item, &a->virtio_flags);
    if (!a) return 0;
    // end field virtio_flags

    // processing virtio_pci_create_v2: u64 features
    item = cJSON_GetObjectItem(o, "features");
    if (!item) return 0;
    // start field features
    vl_api_u64_fromjson(item, &a->features);
    // end field features


    *len = l;
    return a;
}
static inline vl_api_virtio_pci_create_v2_reply_t *vl_api_virtio_pci_create_v2_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_virtio_pci_create_v2_reply_t);
    vl_api_virtio_pci_create_v2_reply_t *a = malloc(l);
    // processing virtio_pci_create_v2_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing virtio_pci_create_v2_reply: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_virtio_pci_delete_t *vl_api_virtio_pci_delete_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_virtio_pci_delete_t);
    vl_api_virtio_pci_delete_t *a = malloc(l);
    // processing virtio_pci_delete: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_virtio_pci_delete_reply_t *vl_api_virtio_pci_delete_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_virtio_pci_delete_reply_t);
    vl_api_virtio_pci_delete_reply_t *a = malloc(l);
    // processing virtio_pci_delete_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_sw_interface_virtio_pci_dump_t *vl_api_sw_interface_virtio_pci_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_virtio_pci_dump_t);
    vl_api_sw_interface_virtio_pci_dump_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_sw_interface_virtio_pci_details_t *vl_api_sw_interface_virtio_pci_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_virtio_pci_details_t);
    vl_api_sw_interface_virtio_pci_details_t *a = malloc(l);
    // processing sw_interface_virtio_pci_details: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing sw_interface_virtio_pci_details: vl_api_pci_address_t pci_addr
    item = cJSON_GetObjectItem(o, "pci_addr");
    if (!item) return 0;
    // start field pci_addr
    a = vl_api_pci_address_t_fromjson(a, &l, item, &a->pci_addr);
    if (!a) return 0;
    // end field pci_addr

    // processing sw_interface_virtio_pci_details: vl_api_mac_address_t mac_addr
    item = cJSON_GetObjectItem(o, "mac_addr");
    if (!item) return 0;
    // start field mac_addr
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->mac_addr);
    if (!a) return 0;
    // end field mac_addr

    // processing sw_interface_virtio_pci_details: u16 tx_ring_sz
    item = cJSON_GetObjectItem(o, "tx_ring_sz");
    if (!item) return 0;
    // start field tx_ring_sz
    vl_api_u16_fromjson(item, &a->tx_ring_sz);
    // end field tx_ring_sz

    // processing sw_interface_virtio_pci_details: u16 rx_ring_sz
    item = cJSON_GetObjectItem(o, "rx_ring_sz");
    if (!item) return 0;
    // start field rx_ring_sz
    vl_api_u16_fromjson(item, &a->rx_ring_sz);
    // end field rx_ring_sz

    // processing sw_interface_virtio_pci_details: u64 features
    item = cJSON_GetObjectItem(o, "features");
    if (!item) return 0;
    // start field features
    vl_api_u64_fromjson(item, &a->features);
    // end field features


    *len = l;
    return a;
}
#endif
