/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#include <vnet/ethernet/ethernet_types.api_fromjson.h>
#include <vnet/ip/ip_types.api_fromjson.h>
#ifndef included_tapv2_api_fromjson_h
#define included_tapv2_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline void *vl_api_tap_flags_t_fromjson (void *mp, int *len, cJSON *o, vl_api_tap_flags_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "TAP_API_FLAG_GSO") == 0) {*a = 1; return mp;}
    if (strcmp(p, "TAP_API_FLAG_CSUM_OFFLOAD") == 0) {*a = 2; return mp;}
    if (strcmp(p, "TAP_API_FLAG_PERSIST") == 0) {*a = 4; return mp;}
    if (strcmp(p, "TAP_API_FLAG_ATTACH") == 0) {*a = 8; return mp;}
    if (strcmp(p, "TAP_API_FLAG_TUN") == 0) {*a = 16; return mp;}
    if (strcmp(p, "TAP_API_FLAG_GRO_COALESCE") == 0) {*a = 32; return mp;}
    if (strcmp(p, "TAP_API_FLAG_PACKED") == 0) {*a = 64; return mp;}
    if (strcmp(p, "TAP_API_FLAG_IN_ORDER") == 0) {*a = 128; return mp;}
   return 0;
}
static inline vl_api_tap_create_v2_t *vl_api_tap_create_v2_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_tap_create_v2_t);
    vl_api_tap_create_v2_t *a = malloc(l);
    // processing tap_create_v2: u32 id
    item = cJSON_GetObjectItem(o, "id");
    if (!item) return 0;
    // start field id
    vl_api_u32_fromjson(item, &a->id);
    // end field id

    // processing tap_create_v2: bool use_random_mac
    item = cJSON_GetObjectItem(o, "use_random_mac");
    if (!item) return 0;
    // start field use_random_mac
    vl_api_bool_fromjson(item, &a->use_random_mac);
    // end field use_random_mac

    // processing tap_create_v2: vl_api_mac_address_t mac_address
    item = cJSON_GetObjectItem(o, "mac_address");
    if (!item) return 0;
    // start field mac_address
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->mac_address);
    if (!a) return 0;
    // end field mac_address

    // processing tap_create_v2: u8 num_rx_queues
    item = cJSON_GetObjectItem(o, "num_rx_queues");
    if (!item) return 0;
    // start field num_rx_queues
    vl_api_u8_fromjson(item, &a->num_rx_queues);
    // end field num_rx_queues

    // processing tap_create_v2: u16 tx_ring_sz
    item = cJSON_GetObjectItem(o, "tx_ring_sz");
    if (!item) return 0;
    // start field tx_ring_sz
    vl_api_u16_fromjson(item, &a->tx_ring_sz);
    // end field tx_ring_sz

    // processing tap_create_v2: u16 rx_ring_sz
    item = cJSON_GetObjectItem(o, "rx_ring_sz");
    if (!item) return 0;
    // start field rx_ring_sz
    vl_api_u16_fromjson(item, &a->rx_ring_sz);
    // end field rx_ring_sz

    // processing tap_create_v2: bool host_mtu_set
    item = cJSON_GetObjectItem(o, "host_mtu_set");
    if (!item) return 0;
    // start field host_mtu_set
    vl_api_bool_fromjson(item, &a->host_mtu_set);
    // end field host_mtu_set

    // processing tap_create_v2: u32 host_mtu_size
    item = cJSON_GetObjectItem(o, "host_mtu_size");
    if (!item) return 0;
    // start field host_mtu_size
    vl_api_u32_fromjson(item, &a->host_mtu_size);
    // end field host_mtu_size

    // processing tap_create_v2: bool host_mac_addr_set
    item = cJSON_GetObjectItem(o, "host_mac_addr_set");
    if (!item) return 0;
    // start field host_mac_addr_set
    vl_api_bool_fromjson(item, &a->host_mac_addr_set);
    // end field host_mac_addr_set

    // processing tap_create_v2: vl_api_mac_address_t host_mac_addr
    item = cJSON_GetObjectItem(o, "host_mac_addr");
    if (!item) return 0;
    // start field host_mac_addr
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->host_mac_addr);
    if (!a) return 0;
    // end field host_mac_addr

    // processing tap_create_v2: bool host_ip4_prefix_set
    item = cJSON_GetObjectItem(o, "host_ip4_prefix_set");
    if (!item) return 0;
    // start field host_ip4_prefix_set
    vl_api_bool_fromjson(item, &a->host_ip4_prefix_set);
    // end field host_ip4_prefix_set

    // processing tap_create_v2: vl_api_ip4_address_with_prefix_t host_ip4_prefix
    item = cJSON_GetObjectItem(o, "host_ip4_prefix");
    if (!item) return 0;
    // start field host_ip4_prefix
    a = vl_api_ip4_address_with_prefix_t_fromjson(a, &l, item, &a->host_ip4_prefix);
    if (!a) return 0;
    // end field host_ip4_prefix

    // processing tap_create_v2: bool host_ip6_prefix_set
    item = cJSON_GetObjectItem(o, "host_ip6_prefix_set");
    if (!item) return 0;
    // start field host_ip6_prefix_set
    vl_api_bool_fromjson(item, &a->host_ip6_prefix_set);
    // end field host_ip6_prefix_set

    // processing tap_create_v2: vl_api_ip6_address_with_prefix_t host_ip6_prefix
    item = cJSON_GetObjectItem(o, "host_ip6_prefix");
    if (!item) return 0;
    // start field host_ip6_prefix
    a = vl_api_ip6_address_with_prefix_t_fromjson(a, &l, item, &a->host_ip6_prefix);
    if (!a) return 0;
    // end field host_ip6_prefix

    // processing tap_create_v2: bool host_ip4_gw_set
    item = cJSON_GetObjectItem(o, "host_ip4_gw_set");
    if (!item) return 0;
    // start field host_ip4_gw_set
    vl_api_bool_fromjson(item, &a->host_ip4_gw_set);
    // end field host_ip4_gw_set

    // processing tap_create_v2: vl_api_ip4_address_t host_ip4_gw
    item = cJSON_GetObjectItem(o, "host_ip4_gw");
    if (!item) return 0;
    // start field host_ip4_gw
    a = vl_api_ip4_address_t_fromjson(a, &l, item, &a->host_ip4_gw);
    if (!a) return 0;
    // end field host_ip4_gw

    // processing tap_create_v2: bool host_ip6_gw_set
    item = cJSON_GetObjectItem(o, "host_ip6_gw_set");
    if (!item) return 0;
    // start field host_ip6_gw_set
    vl_api_bool_fromjson(item, &a->host_ip6_gw_set);
    // end field host_ip6_gw_set

    // processing tap_create_v2: vl_api_ip6_address_t host_ip6_gw
    item = cJSON_GetObjectItem(o, "host_ip6_gw");
    if (!item) return 0;
    // start field host_ip6_gw
    a = vl_api_ip6_address_t_fromjson(a, &l, item, &a->host_ip6_gw);
    if (!a) return 0;
    // end field host_ip6_gw

    // processing tap_create_v2: vl_api_tap_flags_t tap_flags
    item = cJSON_GetObjectItem(o, "tap_flags");
    if (!item) return 0;
    // start field tap_flags
    a = vl_api_tap_flags_t_fromjson(a, &l, item, &a->tap_flags);
    if (!a) return 0;
    // end field tap_flags

    // processing tap_create_v2: bool host_namespace_set
    item = cJSON_GetObjectItem(o, "host_namespace_set");
    if (!item) return 0;
    // start field host_namespace_set
    vl_api_bool_fromjson(item, &a->host_namespace_set);
    // end field host_namespace_set

    // processing tap_create_v2: string host_namespace
    item = cJSON_GetObjectItem(o, "host_namespace");
    if (!item) return 0;
    strncpy_s((char *)a->host_namespace, sizeof(a->host_namespace), cJSON_GetStringValue(item), sizeof(a->host_namespace) - 1);

    // processing tap_create_v2: bool host_if_name_set
    item = cJSON_GetObjectItem(o, "host_if_name_set");
    if (!item) return 0;
    // start field host_if_name_set
    vl_api_bool_fromjson(item, &a->host_if_name_set);
    // end field host_if_name_set

    // processing tap_create_v2: string host_if_name
    item = cJSON_GetObjectItem(o, "host_if_name");
    if (!item) return 0;
    strncpy_s((char *)a->host_if_name, sizeof(a->host_if_name), cJSON_GetStringValue(item), sizeof(a->host_if_name) - 1);

    // processing tap_create_v2: bool host_bridge_set
    item = cJSON_GetObjectItem(o, "host_bridge_set");
    if (!item) return 0;
    // start field host_bridge_set
    vl_api_bool_fromjson(item, &a->host_bridge_set);
    // end field host_bridge_set

    // processing tap_create_v2: string host_bridge
    item = cJSON_GetObjectItem(o, "host_bridge");
    if (!item) return 0;
    strncpy_s((char *)a->host_bridge, sizeof(a->host_bridge), cJSON_GetStringValue(item), sizeof(a->host_bridge) - 1);

    // processing tap_create_v2: string tag
    item = cJSON_GetObjectItem(o, "tag");
    if (!item) return 0;
    char *p = cJSON_GetStringValue(item);
    size_t plen = strlen(p);
    a = realloc(a, l + plen);
    vl_api_c_string_to_api_string(p, (void *)a + l - sizeof(vl_api_string_t));
    l += plen;


    *len = l;
    return a;
}
static inline vl_api_tap_create_v2_reply_t *vl_api_tap_create_v2_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_tap_create_v2_reply_t);
    vl_api_tap_create_v2_reply_t *a = malloc(l);
    // processing tap_create_v2_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing tap_create_v2_reply: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_tap_delete_v2_t *vl_api_tap_delete_v2_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_tap_delete_v2_t);
    vl_api_tap_delete_v2_t *a = malloc(l);
    // processing tap_delete_v2: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_tap_delete_v2_reply_t *vl_api_tap_delete_v2_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_tap_delete_v2_reply_t);
    vl_api_tap_delete_v2_reply_t *a = malloc(l);
    // processing tap_delete_v2_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_sw_interface_tap_v2_dump_t *vl_api_sw_interface_tap_v2_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_tap_v2_dump_t);
    vl_api_sw_interface_tap_v2_dump_t *a = malloc(l);
    // processing sw_interface_tap_v2_dump: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_sw_interface_tap_v2_details_t *vl_api_sw_interface_tap_v2_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_tap_v2_details_t);
    vl_api_sw_interface_tap_v2_details_t *a = malloc(l);
    // processing sw_interface_tap_v2_details: u32 sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    vl_api_u32_fromjson(item, &a->sw_if_index);
    // end field sw_if_index

    // processing sw_interface_tap_v2_details: u32 id
    item = cJSON_GetObjectItem(o, "id");
    if (!item) return 0;
    // start field id
    vl_api_u32_fromjson(item, &a->id);
    // end field id

    // processing sw_interface_tap_v2_details: u16 tx_ring_sz
    item = cJSON_GetObjectItem(o, "tx_ring_sz");
    if (!item) return 0;
    // start field tx_ring_sz
    vl_api_u16_fromjson(item, &a->tx_ring_sz);
    // end field tx_ring_sz

    // processing sw_interface_tap_v2_details: u16 rx_ring_sz
    item = cJSON_GetObjectItem(o, "rx_ring_sz");
    if (!item) return 0;
    // start field rx_ring_sz
    vl_api_u16_fromjson(item, &a->rx_ring_sz);
    // end field rx_ring_sz

    // processing sw_interface_tap_v2_details: u32 host_mtu_size
    item = cJSON_GetObjectItem(o, "host_mtu_size");
    if (!item) return 0;
    // start field host_mtu_size
    vl_api_u32_fromjson(item, &a->host_mtu_size);
    // end field host_mtu_size

    // processing sw_interface_tap_v2_details: vl_api_mac_address_t host_mac_addr
    item = cJSON_GetObjectItem(o, "host_mac_addr");
    if (!item) return 0;
    // start field host_mac_addr
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->host_mac_addr);
    if (!a) return 0;
    // end field host_mac_addr

    // processing sw_interface_tap_v2_details: vl_api_ip4_address_with_prefix_t host_ip4_prefix
    item = cJSON_GetObjectItem(o, "host_ip4_prefix");
    if (!item) return 0;
    // start field host_ip4_prefix
    a = vl_api_ip4_address_with_prefix_t_fromjson(a, &l, item, &a->host_ip4_prefix);
    if (!a) return 0;
    // end field host_ip4_prefix

    // processing sw_interface_tap_v2_details: vl_api_ip6_address_with_prefix_t host_ip6_prefix
    item = cJSON_GetObjectItem(o, "host_ip6_prefix");
    if (!item) return 0;
    // start field host_ip6_prefix
    a = vl_api_ip6_address_with_prefix_t_fromjson(a, &l, item, &a->host_ip6_prefix);
    if (!a) return 0;
    // end field host_ip6_prefix

    // processing sw_interface_tap_v2_details: vl_api_tap_flags_t tap_flags
    item = cJSON_GetObjectItem(o, "tap_flags");
    if (!item) return 0;
    // start field tap_flags
    a = vl_api_tap_flags_t_fromjson(a, &l, item, &a->tap_flags);
    if (!a) return 0;
    // end field tap_flags

    // processing sw_interface_tap_v2_details: string dev_name
    item = cJSON_GetObjectItem(o, "dev_name");
    if (!item) return 0;
    strncpy_s((char *)a->dev_name, sizeof(a->dev_name), cJSON_GetStringValue(item), sizeof(a->dev_name) - 1);

    // processing sw_interface_tap_v2_details: string host_if_name
    item = cJSON_GetObjectItem(o, "host_if_name");
    if (!item) return 0;
    strncpy_s((char *)a->host_if_name, sizeof(a->host_if_name), cJSON_GetStringValue(item), sizeof(a->host_if_name) - 1);

    // processing sw_interface_tap_v2_details: string host_namespace
    item = cJSON_GetObjectItem(o, "host_namespace");
    if (!item) return 0;
    strncpy_s((char *)a->host_namespace, sizeof(a->host_namespace), cJSON_GetStringValue(item), sizeof(a->host_namespace) - 1);

    // processing sw_interface_tap_v2_details: string host_bridge
    item = cJSON_GetObjectItem(o, "host_bridge");
    if (!item) return 0;
    strncpy_s((char *)a->host_bridge, sizeof(a->host_bridge), cJSON_GetStringValue(item), sizeof(a->host_bridge) - 1);


    *len = l;
    return a;
}
#endif
