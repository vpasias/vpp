/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#ifndef included_pipe_api_fromjson_h
#define included_pipe_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline vl_api_pipe_create_t *vl_api_pipe_create_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_pipe_create_t);
    vl_api_pipe_create_t *a = malloc(l);
    // processing pipe_create: bool is_specified
    item = cJSON_GetObjectItem(o, "is_specified");
    if (!item) return 0;
    // start field is_specified
    vl_api_bool_fromjson(item, &a->is_specified);
    // end field is_specified

    // processing pipe_create: u32 user_instance
    item = cJSON_GetObjectItem(o, "user_instance");
    if (!item) return 0;
    // start field user_instance
    vl_api_u32_fromjson(item, &a->user_instance);
    // end field user_instance


    *len = l;
    return a;
}
static inline vl_api_pipe_create_reply_t *vl_api_pipe_create_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_pipe_create_reply_t);
    vl_api_pipe_create_reply_t *a = malloc(l);
    // processing pipe_create_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing pipe_create_reply: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing pipe_create_reply: vl_api_interface_index_t pipe_sw_if_index
    item = cJSON_GetObjectItem(o, "pipe_sw_if_index");
    if (!item) return 0;
    {
        int i;
        cJSON *array = cJSON_GetObjectItem(o, "pipe_sw_if_index");
        int size = cJSON_GetArraySize(array);
        if (size != 2) return 0;
        for (i = 0; i < size; i++) {
            cJSON *e = cJSON_GetArrayItem(array, i);
            a = vl_api_interface_index_t_fromjson(a, len, e, &a->pipe_sw_if_index[i]);
        }
    }


    *len = l;
    return a;
}
static inline vl_api_pipe_delete_t *vl_api_pipe_delete_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_pipe_delete_t);
    vl_api_pipe_delete_t *a = malloc(l);
    // processing pipe_delete: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_pipe_delete_reply_t *vl_api_pipe_delete_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_pipe_delete_reply_t);
    vl_api_pipe_delete_reply_t *a = malloc(l);
    // processing pipe_delete_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_pipe_dump_t *vl_api_pipe_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_pipe_dump_t);
    vl_api_pipe_dump_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_pipe_details_t *vl_api_pipe_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_pipe_details_t);
    vl_api_pipe_details_t *a = malloc(l);
    // processing pipe_details: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing pipe_details: vl_api_interface_index_t pipe_sw_if_index
    item = cJSON_GetObjectItem(o, "pipe_sw_if_index");
    if (!item) return 0;
    {
        int i;
        cJSON *array = cJSON_GetObjectItem(o, "pipe_sw_if_index");
        int size = cJSON_GetArraySize(array);
        if (size != 2) return 0;
        for (i = 0; i < size; i++) {
            cJSON *e = cJSON_GetArrayItem(array, i);
            a = vl_api_interface_index_t_fromjson(a, len, e, &a->pipe_sw_if_index[i]);
        }
    }

    // processing pipe_details: u32 instance
    item = cJSON_GetObjectItem(o, "instance");
    if (!item) return 0;
    // start field instance
    vl_api_u32_fromjson(item, &a->instance);
    // end field instance


    *len = l;
    return a;
}
#endif
