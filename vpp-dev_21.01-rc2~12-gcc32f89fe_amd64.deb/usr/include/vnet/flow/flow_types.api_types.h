#ifndef included_flow_types_api_types_h
#define included_flow_types_api_types_h
#define VL_API_FLOW_TYPES_API_VERSION_MAJOR 0
#define VL_API_FLOW_TYPES_API_VERSION_MINOR 0
#define VL_API_FLOW_TYPES_API_VERSION_PATCH 2
/* Imported API files */
#include <vnet/ethernet/ethernet_types.api_types.h>
#include <vnet/ip/ip_types.api_types.h>
typedef enum {
    FLOW_TYPE_ETHERNET = 1,
    FLOW_TYPE_IP4 = 2,
    FLOW_TYPE_IP6 = 3,
    FLOW_TYPE_IP4_L2TPV3OIP = 4,
    FLOW_TYPE_IP4_IPSEC_ESP = 5,
    FLOW_TYPE_IP4_IPSEC_AH = 6,
    FLOW_TYPE_IP4_N_TUPLE = 7,
    FLOW_TYPE_IP6_N_TUPLE = 8,
    FLOW_TYPE_IP4_N_TUPLE_TAGGED = 9,
    FLOW_TYPE_IP6_N_TUPLE_TAGGED = 10,
    FLOW_TYPE_IP4_VXLAN = 11,
    FLOW_TYPE_IP6_VXLAN = 12,
    FLOW_TYPE_IP4_GTPC = 13,
    FLOW_TYPE_IP4_GTPU = 14,
} vl_api_flow_type_t;
typedef enum {
    FLOW_ACTION_COUNT = 1,
    FLOW_ACTION_MARK = 2,
    FLOW_ACTION_BUFFER_ADVANCE = 4,
    FLOW_ACTION_REDIRECT_TO_NODE = 8,
    FLOW_ACTION_REDIRECT_TO_QUEUE = 16,
    FLOW_ACTION_DROP = 64,
} vl_api_flow_action_t;
typedef struct __attribute__ ((packed)) _vl_api_ip_port_and_mask {
    u16 port;
    u16 mask;
} vl_api_ip_port_and_mask_t;
typedef struct __attribute__ ((packed)) _vl_api_ip_prot_and_mask {
    vl_api_ip_proto_t prot;
    u8 mask;
} vl_api_ip_prot_and_mask_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ethernet {
    i32 foo;
    vl_api_mac_address_t src_addr;
    vl_api_mac_address_t dst_addr;
    u16 type;
} vl_api_flow_ethernet_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip4 {
    i32 foo;
    vl_api_ip4_address_and_mask_t src_addr;
    vl_api_ip4_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
} vl_api_flow_ip4_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip6 {
    i32 foo;
    vl_api_ip6_address_and_mask_t src_addr;
    vl_api_ip6_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
} vl_api_flow_ip6_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip4_n_tuple {
    i32 foo;
    vl_api_ip4_address_and_mask_t src_addr;
    vl_api_ip4_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
    vl_api_ip_port_and_mask_t src_port;
    vl_api_ip_port_and_mask_t dst_port;
} vl_api_flow_ip4_n_tuple_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip6_n_tuple {
    i32 foo;
    vl_api_ip6_address_and_mask_t src_addr;
    vl_api_ip6_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
    vl_api_ip_port_and_mask_t src_port;
    vl_api_ip_port_and_mask_t dst_port;
} vl_api_flow_ip6_n_tuple_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip4_n_tuple_tagged {
    i32 foo;
    vl_api_ip4_address_and_mask_t src_addr;
    vl_api_ip4_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
    vl_api_ip_port_and_mask_t src_port;
    vl_api_ip_port_and_mask_t dst_port;
} vl_api_flow_ip4_n_tuple_tagged_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip6_n_tuple_tagged {
    i32 foo;
    vl_api_ip6_address_and_mask_t src_addr;
    vl_api_ip6_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
    vl_api_ip_port_and_mask_t src_port;
    vl_api_ip_port_and_mask_t dst_port;
} vl_api_flow_ip6_n_tuple_tagged_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip4_l2tpv3oip {
    i32 foo;
    vl_api_ip4_address_and_mask_t src_addr;
    vl_api_ip4_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
    u32 session_id;
} vl_api_flow_ip4_l2tpv3oip_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip4_ipsec_esp {
    i32 foo;
    vl_api_ip4_address_and_mask_t src_addr;
    vl_api_ip4_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
    u32 spi;
} vl_api_flow_ip4_ipsec_esp_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip4_ipsec_ah {
    i32 foo;
    vl_api_ip4_address_and_mask_t src_addr;
    vl_api_ip4_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
    u32 spi;
} vl_api_flow_ip4_ipsec_ah_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip4_vxlan {
    i32 foo;
    vl_api_ip4_address_and_mask_t src_addr;
    vl_api_ip4_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
    vl_api_ip_port_and_mask_t src_port;
    vl_api_ip_port_and_mask_t dst_port;
    u16 vni;
} vl_api_flow_ip4_vxlan_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip6_vxlan {
    i32 foo;
    vl_api_ip6_address_and_mask_t src_addr;
    vl_api_ip6_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
    vl_api_ip_port_and_mask_t src_port;
    vl_api_ip_port_and_mask_t dst_port;
    u16 vni;
} vl_api_flow_ip6_vxlan_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip4_gtpc {
    i32 foo;
    vl_api_ip4_address_and_mask_t src_addr;
    vl_api_ip4_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
    vl_api_ip_port_and_mask_t src_port;
    vl_api_ip_port_and_mask_t dst_port;
    u32 teid;
} vl_api_flow_ip4_gtpc_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_ip4_gtpu {
    i32 foo;
    vl_api_ip4_address_and_mask_t src_addr;
    vl_api_ip4_address_and_mask_t dst_addr;
    vl_api_ip_prot_and_mask_t protocol;
    vl_api_ip_port_and_mask_t src_port;
    vl_api_ip_port_and_mask_t dst_port;
    u32 teid;
} vl_api_flow_ip4_gtpu_t;
typedef union __attribute__ ((packed)) _vl_api_flow {
    vl_api_flow_ethernet_t ethernet;
    vl_api_flow_ip4_t ip4;
    vl_api_flow_ip6_t ip6;
    vl_api_flow_ip4_l2tpv3oip_t ip4_l2tpv3oip;
    vl_api_flow_ip4_ipsec_esp_t ip4_ipsec_esp;
    vl_api_flow_ip4_ipsec_ah_t ip4_ipsec_ah;
    vl_api_flow_ip4_n_tuple_t ip4_n_tuple;
    vl_api_flow_ip6_n_tuple_t ip6_n_tuple;
    vl_api_flow_ip4_n_tuple_tagged_t ip4_n_tuple_tagged;
    vl_api_flow_ip6_n_tuple_tagged_t ip6_n_tuple_tagged;
    vl_api_flow_ip4_vxlan_t ip4_vxlan;
    vl_api_flow_ip6_vxlan_t ip6_vxlan;
    vl_api_flow_ip4_gtpc_t ip4_gtpc;
    vl_api_flow_ip4_gtpu_t ip4_gtpu;
} vl_api_flow_t;
typedef struct __attribute__ ((packed)) _vl_api_flow_rule {
    vl_api_flow_type_t type;
    u32 index;
    vl_api_flow_action_t actions;
    u32 mark_flow_id;
    u32 redirect_node_index;
    u32 redirect_device_input_next_index;
    u32 redirect_queue;
    i32 buffer_advance;
    vl_api_flow_t flow;
} vl_api_flow_rule_t;

#endif
