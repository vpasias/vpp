#ifndef included_flow_types_api_enum_h
#define included_flow_types_api_enum_h
typedef enum {
   VL_MSG_FLOW_TYPES_LAST
} vl_api_flow_types_enum_t;
#endif
