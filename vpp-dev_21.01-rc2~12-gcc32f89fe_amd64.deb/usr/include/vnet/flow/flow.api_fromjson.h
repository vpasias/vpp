/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#include <vnet/ip/ip_types.api_fromjson.h>
#include <vnet/flow/flow_types.api_fromjson.h>
#ifndef included_flow_api_fromjson_h
#define included_flow_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline vl_api_flow_add_t *vl_api_flow_add_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_flow_add_t);
    vl_api_flow_add_t *a = malloc(l);
    // processing flow_add: vl_api_flow_rule_t flow
    item = cJSON_GetObjectItem(o, "flow");
    if (!item) return 0;
    // start field flow
    a = vl_api_flow_rule_t_fromjson(a, &l, item, &a->flow);
    if (!a) return 0;
    // end field flow


    *len = l;
    return a;
}
static inline vl_api_flow_add_reply_t *vl_api_flow_add_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_flow_add_reply_t);
    vl_api_flow_add_reply_t *a = malloc(l);
    // processing flow_add_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing flow_add_reply: u32 flow_index
    item = cJSON_GetObjectItem(o, "flow_index");
    if (!item) return 0;
    // start field flow_index
    vl_api_u32_fromjson(item, &a->flow_index);
    // end field flow_index


    *len = l;
    return a;
}
static inline vl_api_flow_del_t *vl_api_flow_del_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_flow_del_t);
    vl_api_flow_del_t *a = malloc(l);
    // processing flow_del: u32 flow_index
    item = cJSON_GetObjectItem(o, "flow_index");
    if (!item) return 0;
    // start field flow_index
    vl_api_u32_fromjson(item, &a->flow_index);
    // end field flow_index


    *len = l;
    return a;
}
static inline vl_api_flow_del_reply_t *vl_api_flow_del_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_flow_del_reply_t);
    vl_api_flow_del_reply_t *a = malloc(l);
    // processing flow_del_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_flow_enable_t *vl_api_flow_enable_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_flow_enable_t);
    vl_api_flow_enable_t *a = malloc(l);
    // processing flow_enable: u32 flow_index
    item = cJSON_GetObjectItem(o, "flow_index");
    if (!item) return 0;
    // start field flow_index
    vl_api_u32_fromjson(item, &a->flow_index);
    // end field flow_index

    // processing flow_enable: u32 hw_if_index
    item = cJSON_GetObjectItem(o, "hw_if_index");
    if (!item) return 0;
    // start field hw_if_index
    vl_api_u32_fromjson(item, &a->hw_if_index);
    // end field hw_if_index


    *len = l;
    return a;
}
static inline vl_api_flow_enable_reply_t *vl_api_flow_enable_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_flow_enable_reply_t);
    vl_api_flow_enable_reply_t *a = malloc(l);
    // processing flow_enable_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_flow_disable_t *vl_api_flow_disable_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_flow_disable_t);
    vl_api_flow_disable_t *a = malloc(l);
    // processing flow_disable: u32 flow_index
    item = cJSON_GetObjectItem(o, "flow_index");
    if (!item) return 0;
    // start field flow_index
    vl_api_u32_fromjson(item, &a->flow_index);
    // end field flow_index

    // processing flow_disable: u32 hw_if_index
    item = cJSON_GetObjectItem(o, "hw_if_index");
    if (!item) return 0;
    // start field hw_if_index
    vl_api_u32_fromjson(item, &a->hw_if_index);
    // end field hw_if_index


    *len = l;
    return a;
}
static inline vl_api_flow_disable_reply_t *vl_api_flow_disable_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_flow_disable_reply_t);
    vl_api_flow_disable_reply_t *a = malloc(l);
    // processing flow_disable_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
#endif
