/* Imported API files */
#include <vnet/ethernet/ethernet_types.api_fromjson.h>
#include <vnet/ip/ip_types.api_fromjson.h>
#ifndef included_flow_types_api_fromjson_h
#define included_flow_types_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline void *vl_api_flow_type_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_type_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "FLOW_TYPE_ETHERNET") == 0) {*a = 1; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP4") == 0) {*a = 2; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP6") == 0) {*a = 3; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP4_L2TPV3OIP") == 0) {*a = 4; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP4_IPSEC_ESP") == 0) {*a = 5; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP4_IPSEC_AH") == 0) {*a = 6; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP4_N_TUPLE") == 0) {*a = 7; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP6_N_TUPLE") == 0) {*a = 8; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP4_N_TUPLE_TAGGED") == 0) {*a = 9; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP6_N_TUPLE_TAGGED") == 0) {*a = 10; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP4_VXLAN") == 0) {*a = 11; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP6_VXLAN") == 0) {*a = 12; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP4_GTPC") == 0) {*a = 13; return mp;}
    if (strcmp(p, "FLOW_TYPE_IP4_GTPU") == 0) {*a = 14; return mp;}
   return 0;
}
static inline void *vl_api_flow_action_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_action_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "FLOW_ACTION_COUNT") == 0) {*a = 1; return mp;}
    if (strcmp(p, "FLOW_ACTION_MARK") == 0) {*a = 2; return mp;}
    if (strcmp(p, "FLOW_ACTION_BUFFER_ADVANCE") == 0) {*a = 4; return mp;}
    if (strcmp(p, "FLOW_ACTION_REDIRECT_TO_NODE") == 0) {*a = 8; return mp;}
    if (strcmp(p, "FLOW_ACTION_REDIRECT_TO_QUEUE") == 0) {*a = 16; return mp;}
    if (strcmp(p, "FLOW_ACTION_DROP") == 0) {*a = 64; return mp;}
   return 0;
}
static inline void *vl_api_ip_port_and_mask_t_fromjson (void *mp, int *len, cJSON *o, vl_api_ip_port_and_mask_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "port");
    if (!item) return 0;
    // start field port
    vl_api_u16_fromjson(item, &a->port);
    // end field port
    item = cJSON_GetObjectItem(o, "mask");
    if (!item) return 0;
    // start field mask
    vl_api_u16_fromjson(item, &a->mask);
    // end field mask
    return mp;
}
static inline void *vl_api_ip_prot_and_mask_t_fromjson (void *mp, int *len, cJSON *o, vl_api_ip_prot_and_mask_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "prot");
    if (!item) return 0;
    // start field prot
    mp = vl_api_ip_proto_t_fromjson(mp, len, item, &a->prot);
    if (!mp) return 0;
    // end field prot
    item = cJSON_GetObjectItem(o, "mask");
    if (!item) return 0;
    // start field mask
    vl_api_u8_fromjson(item, &a->mask);
    // end field mask
    return mp;
}
static inline void *vl_api_flow_ethernet_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ethernet_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_mac_address_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_mac_address_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "type");
    if (!item) return 0;
    // start field type
    vl_api_u16_fromjson(item, &a->type);
    // end field type
    return mp;
}
static inline void *vl_api_flow_ip4_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip4_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    return mp;
}
static inline void *vl_api_flow_ip6_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip6_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip6_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip6_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    return mp;
}
static inline void *vl_api_flow_ip4_n_tuple_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip4_n_tuple_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    item = cJSON_GetObjectItem(o, "src_port");
    if (!item) return 0;
    // start field src_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->src_port);
    if (!mp) return 0;
    // end field src_port
    item = cJSON_GetObjectItem(o, "dst_port");
    if (!item) return 0;
    // start field dst_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->dst_port);
    if (!mp) return 0;
    // end field dst_port
    return mp;
}
static inline void *vl_api_flow_ip6_n_tuple_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip6_n_tuple_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip6_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip6_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    item = cJSON_GetObjectItem(o, "src_port");
    if (!item) return 0;
    // start field src_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->src_port);
    if (!mp) return 0;
    // end field src_port
    item = cJSON_GetObjectItem(o, "dst_port");
    if (!item) return 0;
    // start field dst_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->dst_port);
    if (!mp) return 0;
    // end field dst_port
    return mp;
}
static inline void *vl_api_flow_ip4_n_tuple_tagged_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip4_n_tuple_tagged_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    item = cJSON_GetObjectItem(o, "src_port");
    if (!item) return 0;
    // start field src_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->src_port);
    if (!mp) return 0;
    // end field src_port
    item = cJSON_GetObjectItem(o, "dst_port");
    if (!item) return 0;
    // start field dst_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->dst_port);
    if (!mp) return 0;
    // end field dst_port
    return mp;
}
static inline void *vl_api_flow_ip6_n_tuple_tagged_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip6_n_tuple_tagged_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip6_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip6_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    item = cJSON_GetObjectItem(o, "src_port");
    if (!item) return 0;
    // start field src_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->src_port);
    if (!mp) return 0;
    // end field src_port
    item = cJSON_GetObjectItem(o, "dst_port");
    if (!item) return 0;
    // start field dst_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->dst_port);
    if (!mp) return 0;
    // end field dst_port
    return mp;
}
static inline void *vl_api_flow_ip4_l2tpv3oip_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip4_l2tpv3oip_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    item = cJSON_GetObjectItem(o, "session_id");
    if (!item) return 0;
    // start field session_id
    vl_api_u32_fromjson(item, &a->session_id);
    // end field session_id
    return mp;
}
static inline void *vl_api_flow_ip4_ipsec_esp_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip4_ipsec_esp_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    item = cJSON_GetObjectItem(o, "spi");
    if (!item) return 0;
    // start field spi
    vl_api_u32_fromjson(item, &a->spi);
    // end field spi
    return mp;
}
static inline void *vl_api_flow_ip4_ipsec_ah_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip4_ipsec_ah_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    item = cJSON_GetObjectItem(o, "spi");
    if (!item) return 0;
    // start field spi
    vl_api_u32_fromjson(item, &a->spi);
    // end field spi
    return mp;
}
static inline void *vl_api_flow_ip4_vxlan_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip4_vxlan_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    item = cJSON_GetObjectItem(o, "src_port");
    if (!item) return 0;
    // start field src_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->src_port);
    if (!mp) return 0;
    // end field src_port
    item = cJSON_GetObjectItem(o, "dst_port");
    if (!item) return 0;
    // start field dst_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->dst_port);
    if (!mp) return 0;
    // end field dst_port
    item = cJSON_GetObjectItem(o, "vni");
    if (!item) return 0;
    // start field vni
    vl_api_u16_fromjson(item, &a->vni);
    // end field vni
    return mp;
}
static inline void *vl_api_flow_ip6_vxlan_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip6_vxlan_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip6_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip6_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    item = cJSON_GetObjectItem(o, "src_port");
    if (!item) return 0;
    // start field src_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->src_port);
    if (!mp) return 0;
    // end field src_port
    item = cJSON_GetObjectItem(o, "dst_port");
    if (!item) return 0;
    // start field dst_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->dst_port);
    if (!mp) return 0;
    // end field dst_port
    item = cJSON_GetObjectItem(o, "vni");
    if (!item) return 0;
    // start field vni
    vl_api_u16_fromjson(item, &a->vni);
    // end field vni
    return mp;
}
static inline void *vl_api_flow_ip4_gtpc_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip4_gtpc_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    item = cJSON_GetObjectItem(o, "src_port");
    if (!item) return 0;
    // start field src_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->src_port);
    if (!mp) return 0;
    // end field src_port
    item = cJSON_GetObjectItem(o, "dst_port");
    if (!item) return 0;
    // start field dst_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->dst_port);
    if (!mp) return 0;
    // end field dst_port
    item = cJSON_GetObjectItem(o, "teid");
    if (!item) return 0;
    // start field teid
    vl_api_u32_fromjson(item, &a->teid);
    // end field teid
    return mp;
}
static inline void *vl_api_flow_ip4_gtpu_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_ip4_gtpu_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "foo");
    if (!item) return 0;
    // start field foo
    vl_api_i32_fromjson(item, &a->foo);
    // end field foo
    item = cJSON_GetObjectItem(o, "src_addr");
    if (!item) return 0;
    // start field src_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->src_addr);
    if (!mp) return 0;
    // end field src_addr
    item = cJSON_GetObjectItem(o, "dst_addr");
    if (!item) return 0;
    // start field dst_addr
    mp = vl_api_ip4_address_and_mask_t_fromjson(mp, len, item, &a->dst_addr);
    if (!mp) return 0;
    // end field dst_addr
    item = cJSON_GetObjectItem(o, "protocol");
    if (!item) return 0;
    // start field protocol
    mp = vl_api_ip_prot_and_mask_t_fromjson(mp, len, item, &a->protocol);
    if (!mp) return 0;
    // end field protocol
    item = cJSON_GetObjectItem(o, "src_port");
    if (!item) return 0;
    // start field src_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->src_port);
    if (!mp) return 0;
    // end field src_port
    item = cJSON_GetObjectItem(o, "dst_port");
    if (!item) return 0;
    // start field dst_port
    mp = vl_api_ip_port_and_mask_t_fromjson(mp, len, item, &a->dst_port);
    if (!mp) return 0;
    // end field dst_port
    item = cJSON_GetObjectItem(o, "teid");
    if (!item) return 0;
    // start field teid
    vl_api_u32_fromjson(item, &a->teid);
    // end field teid
    return mp;
}
static inline void *vl_api_flow_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "ethernet");
    if (item) {
    // start field ethernet
    mp = vl_api_flow_ethernet_t_fromjson(mp, len, item, &a->ethernet);
    if (!mp) return 0;
    // end field ethernet
    };
    item = cJSON_GetObjectItem(o, "ip4");
    if (item) {
    // start field ip4
    mp = vl_api_flow_ip4_t_fromjson(mp, len, item, &a->ip4);
    if (!mp) return 0;
    // end field ip4
    };
    item = cJSON_GetObjectItem(o, "ip6");
    if (item) {
    // start field ip6
    mp = vl_api_flow_ip6_t_fromjson(mp, len, item, &a->ip6);
    if (!mp) return 0;
    // end field ip6
    };
    item = cJSON_GetObjectItem(o, "ip4_l2tpv3oip");
    if (item) {
    // start field ip4_l2tpv3oip
    mp = vl_api_flow_ip4_l2tpv3oip_t_fromjson(mp, len, item, &a->ip4_l2tpv3oip);
    if (!mp) return 0;
    // end field ip4_l2tpv3oip
    };
    item = cJSON_GetObjectItem(o, "ip4_ipsec_esp");
    if (item) {
    // start field ip4_ipsec_esp
    mp = vl_api_flow_ip4_ipsec_esp_t_fromjson(mp, len, item, &a->ip4_ipsec_esp);
    if (!mp) return 0;
    // end field ip4_ipsec_esp
    };
    item = cJSON_GetObjectItem(o, "ip4_ipsec_ah");
    if (item) {
    // start field ip4_ipsec_ah
    mp = vl_api_flow_ip4_ipsec_ah_t_fromjson(mp, len, item, &a->ip4_ipsec_ah);
    if (!mp) return 0;
    // end field ip4_ipsec_ah
    };
    item = cJSON_GetObjectItem(o, "ip4_n_tuple");
    if (item) {
    // start field ip4_n_tuple
    mp = vl_api_flow_ip4_n_tuple_t_fromjson(mp, len, item, &a->ip4_n_tuple);
    if (!mp) return 0;
    // end field ip4_n_tuple
    };
    item = cJSON_GetObjectItem(o, "ip6_n_tuple");
    if (item) {
    // start field ip6_n_tuple
    mp = vl_api_flow_ip6_n_tuple_t_fromjson(mp, len, item, &a->ip6_n_tuple);
    if (!mp) return 0;
    // end field ip6_n_tuple
    };
    item = cJSON_GetObjectItem(o, "ip4_n_tuple_tagged");
    if (item) {
    // start field ip4_n_tuple_tagged
    mp = vl_api_flow_ip4_n_tuple_tagged_t_fromjson(mp, len, item, &a->ip4_n_tuple_tagged);
    if (!mp) return 0;
    // end field ip4_n_tuple_tagged
    };
    item = cJSON_GetObjectItem(o, "ip6_n_tuple_tagged");
    if (item) {
    // start field ip6_n_tuple_tagged
    mp = vl_api_flow_ip6_n_tuple_tagged_t_fromjson(mp, len, item, &a->ip6_n_tuple_tagged);
    if (!mp) return 0;
    // end field ip6_n_tuple_tagged
    };
    item = cJSON_GetObjectItem(o, "ip4_vxlan");
    if (item) {
    // start field ip4_vxlan
    mp = vl_api_flow_ip4_vxlan_t_fromjson(mp, len, item, &a->ip4_vxlan);
    if (!mp) return 0;
    // end field ip4_vxlan
    };
    item = cJSON_GetObjectItem(o, "ip6_vxlan");
    if (item) {
    // start field ip6_vxlan
    mp = vl_api_flow_ip6_vxlan_t_fromjson(mp, len, item, &a->ip6_vxlan);
    if (!mp) return 0;
    // end field ip6_vxlan
    };
    item = cJSON_GetObjectItem(o, "ip4_gtpc");
    if (item) {
    // start field ip4_gtpc
    mp = vl_api_flow_ip4_gtpc_t_fromjson(mp, len, item, &a->ip4_gtpc);
    if (!mp) return 0;
    // end field ip4_gtpc
    };
    item = cJSON_GetObjectItem(o, "ip4_gtpu");
    if (item) {
    // start field ip4_gtpu
    mp = vl_api_flow_ip4_gtpu_t_fromjson(mp, len, item, &a->ip4_gtpu);
    if (!mp) return 0;
    // end field ip4_gtpu
    };
    return mp;
}
static inline void *vl_api_flow_rule_t_fromjson (void *mp, int *len, cJSON *o, vl_api_flow_rule_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "type");
    if (!item) return 0;
    // start field type
    mp = vl_api_flow_type_t_fromjson(mp, len, item, &a->type);
    if (!mp) return 0;
    // end field type
    item = cJSON_GetObjectItem(o, "index");
    if (!item) return 0;
    // start field index
    vl_api_u32_fromjson(item, &a->index);
    // end field index
    item = cJSON_GetObjectItem(o, "actions");
    if (!item) return 0;
    // start field actions
    mp = vl_api_flow_action_t_fromjson(mp, len, item, &a->actions);
    if (!mp) return 0;
    // end field actions
    item = cJSON_GetObjectItem(o, "mark_flow_id");
    if (!item) return 0;
    // start field mark_flow_id
    vl_api_u32_fromjson(item, &a->mark_flow_id);
    // end field mark_flow_id
    item = cJSON_GetObjectItem(o, "redirect_node_index");
    if (!item) return 0;
    // start field redirect_node_index
    vl_api_u32_fromjson(item, &a->redirect_node_index);
    // end field redirect_node_index
    item = cJSON_GetObjectItem(o, "redirect_device_input_next_index");
    if (!item) return 0;
    // start field redirect_device_input_next_index
    vl_api_u32_fromjson(item, &a->redirect_device_input_next_index);
    // end field redirect_device_input_next_index
    item = cJSON_GetObjectItem(o, "redirect_queue");
    if (!item) return 0;
    // start field redirect_queue
    vl_api_u32_fromjson(item, &a->redirect_queue);
    // end field redirect_queue
    item = cJSON_GetObjectItem(o, "buffer_advance");
    if (!item) return 0;
    // start field buffer_advance
    vl_api_i32_fromjson(item, &a->buffer_advance);
    // end field buffer_advance
    item = cJSON_GetObjectItem(o, "flow");
    if (!item) return 0;
    // start field flow
    mp = vl_api_flow_t_fromjson(mp, len, item, &a->flow);
    if (!mp) return 0;
    // end field flow
    return mp;
}
#endif
