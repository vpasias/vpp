#ifndef included_ethernet_types_api_enum_h
#define included_ethernet_types_api_enum_h
typedef enum {
   VL_MSG_ETHERNET_TYPES_LAST
} vl_api_ethernet_types_enum_t;
#endif
