/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#include <vnet/ethernet/ethernet_types.api_fromjson.h>
#ifndef included_p2p_ethernet_api_fromjson_h
#define included_p2p_ethernet_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline vl_api_p2p_ethernet_add_t *vl_api_p2p_ethernet_add_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_p2p_ethernet_add_t);
    vl_api_p2p_ethernet_add_t *a = malloc(l);
    // processing p2p_ethernet_add: vl_api_interface_index_t parent_if_index
    item = cJSON_GetObjectItem(o, "parent_if_index");
    if (!item) return 0;
    // start field parent_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->parent_if_index);
    if (!a) return 0;
    // end field parent_if_index

    // processing p2p_ethernet_add: u32 subif_id
    item = cJSON_GetObjectItem(o, "subif_id");
    if (!item) return 0;
    // start field subif_id
    vl_api_u32_fromjson(item, &a->subif_id);
    // end field subif_id

    // processing p2p_ethernet_add: vl_api_mac_address_t remote_mac
    item = cJSON_GetObjectItem(o, "remote_mac");
    if (!item) return 0;
    // start field remote_mac
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->remote_mac);
    if (!a) return 0;
    // end field remote_mac


    *len = l;
    return a;
}
static inline vl_api_p2p_ethernet_add_reply_t *vl_api_p2p_ethernet_add_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_p2p_ethernet_add_reply_t);
    vl_api_p2p_ethernet_add_reply_t *a = malloc(l);
    // processing p2p_ethernet_add_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing p2p_ethernet_add_reply: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_p2p_ethernet_del_t *vl_api_p2p_ethernet_del_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_p2p_ethernet_del_t);
    vl_api_p2p_ethernet_del_t *a = malloc(l);
    // processing p2p_ethernet_del: vl_api_interface_index_t parent_if_index
    item = cJSON_GetObjectItem(o, "parent_if_index");
    if (!item) return 0;
    // start field parent_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->parent_if_index);
    if (!a) return 0;
    // end field parent_if_index

    // processing p2p_ethernet_del: vl_api_mac_address_t remote_mac
    item = cJSON_GetObjectItem(o, "remote_mac");
    if (!item) return 0;
    // start field remote_mac
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->remote_mac);
    if (!a) return 0;
    // end field remote_mac


    *len = l;
    return a;
}
static inline vl_api_p2p_ethernet_del_reply_t *vl_api_p2p_ethernet_del_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_p2p_ethernet_del_reply_t);
    vl_api_p2p_ethernet_del_reply_t *a = malloc(l);
    // processing p2p_ethernet_del_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
#endif
