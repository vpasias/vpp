/* Imported API files */
#include <vnet/interface_types.api_fromjson.h>
#include <vnet/ethernet/ethernet_types.api_fromjson.h>
#ifndef included_bond_api_fromjson_h
#define included_bond_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline void *vl_api_bond_mode_t_fromjson (void *mp, int *len, cJSON *o, vl_api_bond_mode_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "BOND_API_MODE_ROUND_ROBIN") == 0) {*a = 1; return mp;}
    if (strcmp(p, "BOND_API_MODE_ACTIVE_BACKUP") == 0) {*a = 2; return mp;}
    if (strcmp(p, "BOND_API_MODE_XOR") == 0) {*a = 3; return mp;}
    if (strcmp(p, "BOND_API_MODE_BROADCAST") == 0) {*a = 4; return mp;}
    if (strcmp(p, "BOND_API_MODE_LACP") == 0) {*a = 5; return mp;}
   return 0;
}
static inline void *vl_api_bond_lb_algo_t_fromjson (void *mp, int *len, cJSON *o, vl_api_bond_lb_algo_t *a) {
    char *p = cJSON_GetStringValue(o);
    if (strcmp(p, "BOND_API_LB_ALGO_L2") == 0) {*a = 0; return mp;}
    if (strcmp(p, "BOND_API_LB_ALGO_L34") == 0) {*a = 1; return mp;}
    if (strcmp(p, "BOND_API_LB_ALGO_L23") == 0) {*a = 2; return mp;}
    if (strcmp(p, "BOND_API_LB_ALGO_RR") == 0) {*a = 3; return mp;}
    if (strcmp(p, "BOND_API_LB_ALGO_BC") == 0) {*a = 4; return mp;}
    if (strcmp(p, "BOND_API_LB_ALGO_AB") == 0) {*a = 5; return mp;}
   return 0;
}
static inline vl_api_bond_create_t *vl_api_bond_create_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_create_t);
    vl_api_bond_create_t *a = malloc(l);
    // processing bond_create: u32 id
    item = cJSON_GetObjectItem(o, "id");
    if (!item) return 0;
    // start field id
    vl_api_u32_fromjson(item, &a->id);
    // end field id

    // processing bond_create: bool use_custom_mac
    item = cJSON_GetObjectItem(o, "use_custom_mac");
    if (!item) return 0;
    // start field use_custom_mac
    vl_api_bool_fromjson(item, &a->use_custom_mac);
    // end field use_custom_mac

    // processing bond_create: vl_api_mac_address_t mac_address
    item = cJSON_GetObjectItem(o, "mac_address");
    if (!item) return 0;
    // start field mac_address
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->mac_address);
    if (!a) return 0;
    // end field mac_address

    // processing bond_create: vl_api_bond_mode_t mode
    item = cJSON_GetObjectItem(o, "mode");
    if (!item) return 0;
    // start field mode
    a = vl_api_bond_mode_t_fromjson(a, &l, item, &a->mode);
    if (!a) return 0;
    // end field mode

    // processing bond_create: vl_api_bond_lb_algo_t lb
    item = cJSON_GetObjectItem(o, "lb");
    if (!item) return 0;
    // start field lb
    a = vl_api_bond_lb_algo_t_fromjson(a, &l, item, &a->lb);
    if (!a) return 0;
    // end field lb

    // processing bond_create: bool numa_only
    item = cJSON_GetObjectItem(o, "numa_only");
    if (!item) return 0;
    // start field numa_only
    vl_api_bool_fromjson(item, &a->numa_only);
    // end field numa_only


    *len = l;
    return a;
}
static inline vl_api_bond_create_reply_t *vl_api_bond_create_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_create_reply_t);
    vl_api_bond_create_reply_t *a = malloc(l);
    // processing bond_create_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing bond_create_reply: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_bond_create2_t *vl_api_bond_create2_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_create2_t);
    vl_api_bond_create2_t *a = malloc(l);
    // processing bond_create2: vl_api_bond_mode_t mode
    item = cJSON_GetObjectItem(o, "mode");
    if (!item) return 0;
    // start field mode
    a = vl_api_bond_mode_t_fromjson(a, &l, item, &a->mode);
    if (!a) return 0;
    // end field mode

    // processing bond_create2: vl_api_bond_lb_algo_t lb
    item = cJSON_GetObjectItem(o, "lb");
    if (!item) return 0;
    // start field lb
    a = vl_api_bond_lb_algo_t_fromjson(a, &l, item, &a->lb);
    if (!a) return 0;
    // end field lb

    // processing bond_create2: bool numa_only
    item = cJSON_GetObjectItem(o, "numa_only");
    if (!item) return 0;
    // start field numa_only
    vl_api_bool_fromjson(item, &a->numa_only);
    // end field numa_only

    // processing bond_create2: bool enable_gso
    item = cJSON_GetObjectItem(o, "enable_gso");
    if (!item) return 0;
    // start field enable_gso
    vl_api_bool_fromjson(item, &a->enable_gso);
    // end field enable_gso

    // processing bond_create2: bool use_custom_mac
    item = cJSON_GetObjectItem(o, "use_custom_mac");
    if (!item) return 0;
    // start field use_custom_mac
    vl_api_bool_fromjson(item, &a->use_custom_mac);
    // end field use_custom_mac

    // processing bond_create2: vl_api_mac_address_t mac_address
    item = cJSON_GetObjectItem(o, "mac_address");
    if (!item) return 0;
    // start field mac_address
    a = vl_api_mac_address_t_fromjson(a, &l, item, &a->mac_address);
    if (!a) return 0;
    // end field mac_address

    // processing bond_create2: u32 id
    item = cJSON_GetObjectItem(o, "id");
    if (!item) return 0;
    // start field id
    vl_api_u32_fromjson(item, &a->id);
    // end field id


    *len = l;
    return a;
}
static inline vl_api_bond_create2_reply_t *vl_api_bond_create2_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_create2_reply_t);
    vl_api_bond_create2_reply_t *a = malloc(l);
    // processing bond_create2_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval

    // processing bond_create2_reply: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_bond_delete_t *vl_api_bond_delete_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_delete_t);
    vl_api_bond_delete_t *a = malloc(l);
    // processing bond_delete: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_bond_delete_reply_t *vl_api_bond_delete_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_delete_reply_t);
    vl_api_bond_delete_reply_t *a = malloc(l);
    // processing bond_delete_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bond_enslave_t *vl_api_bond_enslave_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_enslave_t);
    vl_api_bond_enslave_t *a = malloc(l);
    // processing bond_enslave: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing bond_enslave: vl_api_interface_index_t bond_sw_if_index
    item = cJSON_GetObjectItem(o, "bond_sw_if_index");
    if (!item) return 0;
    // start field bond_sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->bond_sw_if_index);
    if (!a) return 0;
    // end field bond_sw_if_index

    // processing bond_enslave: bool is_passive
    item = cJSON_GetObjectItem(o, "is_passive");
    if (!item) return 0;
    // start field is_passive
    vl_api_bool_fromjson(item, &a->is_passive);
    // end field is_passive

    // processing bond_enslave: bool is_long_timeout
    item = cJSON_GetObjectItem(o, "is_long_timeout");
    if (!item) return 0;
    // start field is_long_timeout
    vl_api_bool_fromjson(item, &a->is_long_timeout);
    // end field is_long_timeout


    *len = l;
    return a;
}
static inline vl_api_bond_enslave_reply_t *vl_api_bond_enslave_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_enslave_reply_t);
    vl_api_bond_enslave_reply_t *a = malloc(l);
    // processing bond_enslave_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bond_add_member_t *vl_api_bond_add_member_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_add_member_t);
    vl_api_bond_add_member_t *a = malloc(l);
    // processing bond_add_member: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing bond_add_member: vl_api_interface_index_t bond_sw_if_index
    item = cJSON_GetObjectItem(o, "bond_sw_if_index");
    if (!item) return 0;
    // start field bond_sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->bond_sw_if_index);
    if (!a) return 0;
    // end field bond_sw_if_index

    // processing bond_add_member: bool is_passive
    item = cJSON_GetObjectItem(o, "is_passive");
    if (!item) return 0;
    // start field is_passive
    vl_api_bool_fromjson(item, &a->is_passive);
    // end field is_passive

    // processing bond_add_member: bool is_long_timeout
    item = cJSON_GetObjectItem(o, "is_long_timeout");
    if (!item) return 0;
    // start field is_long_timeout
    vl_api_bool_fromjson(item, &a->is_long_timeout);
    // end field is_long_timeout


    *len = l;
    return a;
}
static inline vl_api_bond_add_member_reply_t *vl_api_bond_add_member_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_add_member_reply_t);
    vl_api_bond_add_member_reply_t *a = malloc(l);
    // processing bond_add_member_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bond_detach_slave_t *vl_api_bond_detach_slave_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_detach_slave_t);
    vl_api_bond_detach_slave_t *a = malloc(l);
    // processing bond_detach_slave: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_bond_detach_slave_reply_t *vl_api_bond_detach_slave_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_detach_slave_reply_t);
    vl_api_bond_detach_slave_reply_t *a = malloc(l);
    // processing bond_detach_slave_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_bond_detach_member_t *vl_api_bond_detach_member_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_detach_member_t);
    vl_api_bond_detach_member_t *a = malloc(l);
    // processing bond_detach_member: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_bond_detach_member_reply_t *vl_api_bond_detach_member_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_bond_detach_member_reply_t);
    vl_api_bond_detach_member_reply_t *a = malloc(l);
    // processing bond_detach_member_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
static inline vl_api_sw_interface_bond_dump_t *vl_api_sw_interface_bond_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_bond_dump_t);
    vl_api_sw_interface_bond_dump_t *a = malloc(l);

    *len = l;
    return a;
}
static inline vl_api_sw_interface_bond_details_t *vl_api_sw_interface_bond_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_bond_details_t);
    vl_api_sw_interface_bond_details_t *a = malloc(l);
    // processing sw_interface_bond_details: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing sw_interface_bond_details: u32 id
    item = cJSON_GetObjectItem(o, "id");
    if (!item) return 0;
    // start field id
    vl_api_u32_fromjson(item, &a->id);
    // end field id

    // processing sw_interface_bond_details: vl_api_bond_mode_t mode
    item = cJSON_GetObjectItem(o, "mode");
    if (!item) return 0;
    // start field mode
    a = vl_api_bond_mode_t_fromjson(a, &l, item, &a->mode);
    if (!a) return 0;
    // end field mode

    // processing sw_interface_bond_details: vl_api_bond_lb_algo_t lb
    item = cJSON_GetObjectItem(o, "lb");
    if (!item) return 0;
    // start field lb
    a = vl_api_bond_lb_algo_t_fromjson(a, &l, item, &a->lb);
    if (!a) return 0;
    // end field lb

    // processing sw_interface_bond_details: bool numa_only
    item = cJSON_GetObjectItem(o, "numa_only");
    if (!item) return 0;
    // start field numa_only
    vl_api_bool_fromjson(item, &a->numa_only);
    // end field numa_only

    // processing sw_interface_bond_details: u32 active_slaves
    item = cJSON_GetObjectItem(o, "active_slaves");
    if (!item) return 0;
    // start field active_slaves
    vl_api_u32_fromjson(item, &a->active_slaves);
    // end field active_slaves

    // processing sw_interface_bond_details: u32 slaves
    item = cJSON_GetObjectItem(o, "slaves");
    if (!item) return 0;
    // start field slaves
    vl_api_u32_fromjson(item, &a->slaves);
    // end field slaves

    // processing sw_interface_bond_details: string interface_name
    item = cJSON_GetObjectItem(o, "interface_name");
    if (!item) return 0;
    strncpy_s((char *)a->interface_name, sizeof(a->interface_name), cJSON_GetStringValue(item), sizeof(a->interface_name) - 1);


    *len = l;
    return a;
}
static inline vl_api_sw_bond_interface_dump_t *vl_api_sw_bond_interface_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_bond_interface_dump_t);
    vl_api_sw_bond_interface_dump_t *a = malloc(l);
    // processing sw_bond_interface_dump: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_sw_bond_interface_details_t *vl_api_sw_bond_interface_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_bond_interface_details_t);
    vl_api_sw_bond_interface_details_t *a = malloc(l);
    // processing sw_bond_interface_details: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing sw_bond_interface_details: u32 id
    item = cJSON_GetObjectItem(o, "id");
    if (!item) return 0;
    // start field id
    vl_api_u32_fromjson(item, &a->id);
    // end field id

    // processing sw_bond_interface_details: vl_api_bond_mode_t mode
    item = cJSON_GetObjectItem(o, "mode");
    if (!item) return 0;
    // start field mode
    a = vl_api_bond_mode_t_fromjson(a, &l, item, &a->mode);
    if (!a) return 0;
    // end field mode

    // processing sw_bond_interface_details: vl_api_bond_lb_algo_t lb
    item = cJSON_GetObjectItem(o, "lb");
    if (!item) return 0;
    // start field lb
    a = vl_api_bond_lb_algo_t_fromjson(a, &l, item, &a->lb);
    if (!a) return 0;
    // end field lb

    // processing sw_bond_interface_details: bool numa_only
    item = cJSON_GetObjectItem(o, "numa_only");
    if (!item) return 0;
    // start field numa_only
    vl_api_bool_fromjson(item, &a->numa_only);
    // end field numa_only

    // processing sw_bond_interface_details: u32 active_members
    item = cJSON_GetObjectItem(o, "active_members");
    if (!item) return 0;
    // start field active_members
    vl_api_u32_fromjson(item, &a->active_members);
    // end field active_members

    // processing sw_bond_interface_details: u32 members
    item = cJSON_GetObjectItem(o, "members");
    if (!item) return 0;
    // start field members
    vl_api_u32_fromjson(item, &a->members);
    // end field members

    // processing sw_bond_interface_details: string interface_name
    item = cJSON_GetObjectItem(o, "interface_name");
    if (!item) return 0;
    strncpy_s((char *)a->interface_name, sizeof(a->interface_name), cJSON_GetStringValue(item), sizeof(a->interface_name) - 1);


    *len = l;
    return a;
}
static inline vl_api_sw_interface_slave_dump_t *vl_api_sw_interface_slave_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_slave_dump_t);
    vl_api_sw_interface_slave_dump_t *a = malloc(l);
    // processing sw_interface_slave_dump: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_sw_interface_slave_details_t *vl_api_sw_interface_slave_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_slave_details_t);
    vl_api_sw_interface_slave_details_t *a = malloc(l);
    // processing sw_interface_slave_details: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing sw_interface_slave_details: string interface_name
    item = cJSON_GetObjectItem(o, "interface_name");
    if (!item) return 0;
    strncpy_s((char *)a->interface_name, sizeof(a->interface_name), cJSON_GetStringValue(item), sizeof(a->interface_name) - 1);

    // processing sw_interface_slave_details: bool is_passive
    item = cJSON_GetObjectItem(o, "is_passive");
    if (!item) return 0;
    // start field is_passive
    vl_api_bool_fromjson(item, &a->is_passive);
    // end field is_passive

    // processing sw_interface_slave_details: bool is_long_timeout
    item = cJSON_GetObjectItem(o, "is_long_timeout");
    if (!item) return 0;
    // start field is_long_timeout
    vl_api_bool_fromjson(item, &a->is_long_timeout);
    // end field is_long_timeout

    // processing sw_interface_slave_details: bool is_local_numa
    item = cJSON_GetObjectItem(o, "is_local_numa");
    if (!item) return 0;
    // start field is_local_numa
    vl_api_bool_fromjson(item, &a->is_local_numa);
    // end field is_local_numa

    // processing sw_interface_slave_details: u32 weight
    item = cJSON_GetObjectItem(o, "weight");
    if (!item) return 0;
    // start field weight
    vl_api_u32_fromjson(item, &a->weight);
    // end field weight


    *len = l;
    return a;
}
static inline vl_api_sw_member_interface_dump_t *vl_api_sw_member_interface_dump_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_member_interface_dump_t);
    vl_api_sw_member_interface_dump_t *a = malloc(l);
    // processing sw_member_interface_dump: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index


    *len = l;
    return a;
}
static inline vl_api_sw_member_interface_details_t *vl_api_sw_member_interface_details_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_member_interface_details_t);
    vl_api_sw_member_interface_details_t *a = malloc(l);
    // processing sw_member_interface_details: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing sw_member_interface_details: string interface_name
    item = cJSON_GetObjectItem(o, "interface_name");
    if (!item) return 0;
    strncpy_s((char *)a->interface_name, sizeof(a->interface_name), cJSON_GetStringValue(item), sizeof(a->interface_name) - 1);

    // processing sw_member_interface_details: bool is_passive
    item = cJSON_GetObjectItem(o, "is_passive");
    if (!item) return 0;
    // start field is_passive
    vl_api_bool_fromjson(item, &a->is_passive);
    // end field is_passive

    // processing sw_member_interface_details: bool is_long_timeout
    item = cJSON_GetObjectItem(o, "is_long_timeout");
    if (!item) return 0;
    // start field is_long_timeout
    vl_api_bool_fromjson(item, &a->is_long_timeout);
    // end field is_long_timeout

    // processing sw_member_interface_details: bool is_local_numa
    item = cJSON_GetObjectItem(o, "is_local_numa");
    if (!item) return 0;
    // start field is_local_numa
    vl_api_bool_fromjson(item, &a->is_local_numa);
    // end field is_local_numa

    // processing sw_member_interface_details: u32 weight
    item = cJSON_GetObjectItem(o, "weight");
    if (!item) return 0;
    // start field weight
    vl_api_u32_fromjson(item, &a->weight);
    // end field weight


    *len = l;
    return a;
}
static inline vl_api_sw_interface_set_bond_weight_t *vl_api_sw_interface_set_bond_weight_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_set_bond_weight_t);
    vl_api_sw_interface_set_bond_weight_t *a = malloc(l);
    // processing sw_interface_set_bond_weight: vl_api_interface_index_t sw_if_index
    item = cJSON_GetObjectItem(o, "sw_if_index");
    if (!item) return 0;
    // start field sw_if_index
    a = vl_api_interface_index_t_fromjson(a, &l, item, &a->sw_if_index);
    if (!a) return 0;
    // end field sw_if_index

    // processing sw_interface_set_bond_weight: u32 weight
    item = cJSON_GetObjectItem(o, "weight");
    if (!item) return 0;
    // start field weight
    vl_api_u32_fromjson(item, &a->weight);
    // end field weight


    *len = l;
    return a;
}
static inline vl_api_sw_interface_set_bond_weight_reply_t *vl_api_sw_interface_set_bond_weight_reply_t_fromjson (cJSON *o, int *len) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    int l = sizeof(vl_api_sw_interface_set_bond_weight_reply_t);
    vl_api_sw_interface_set_bond_weight_reply_t *a = malloc(l);
    // processing sw_interface_set_bond_weight_reply: i32 retval
    item = cJSON_GetObjectItem(o, "retval");
    if (!item) return 0;
    // start field retval
    vl_api_i32_fromjson(item, &a->retval);
    // end field retval


    *len = l;
    return a;
}
#endif
