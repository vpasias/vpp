/* Imported API files */
#ifndef included_pci_types_api_fromjson_h
#define included_pci_types_api_fromjson_h
#include <vppinfra/cJSON.h>

#include <vat2/jsonconvert.h>

static inline void *vl_api_pci_address_t_fromjson (void *mp, int *len, cJSON *o, vl_api_pci_address_t *a) {
    cJSON *item __attribute__ ((unused));
    u8 *s __attribute__ ((unused));
    item = cJSON_GetObjectItem(o, "domain");
    if (!item) return 0;
    // start field domain
    vl_api_u16_fromjson(item, &a->domain);
    // end field domain
    item = cJSON_GetObjectItem(o, "bus");
    if (!item) return 0;
    // start field bus
    vl_api_u8_fromjson(item, &a->bus);
    // end field bus
    item = cJSON_GetObjectItem(o, "slot");
    if (!item) return 0;
    // start field slot
    vl_api_u8_fromjson(item, &a->slot);
    // end field slot
    item = cJSON_GetObjectItem(o, "function");
    if (!item) return 0;
    // start field function
    vl_api_u8_fromjson(item, &a->function);
    // end field function
    return mp;
}
#endif
